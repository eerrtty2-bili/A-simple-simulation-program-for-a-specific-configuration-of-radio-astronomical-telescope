"""数学工具: Bessel J1, HPBW 提取, 指标计算, 视场分析"""

import numpy as np
import constants as C


def bessel_j1(x):
    """一阶第一类贝塞尔函数 J1(x) — 级数展开 + 渐近近似"""
    x = np.asarray(x, dtype=float)
    is_scalar = x.ndim == 0
    x = np.atleast_1d(x)
    r = np.zeros_like(x)
    # 小参数: 级数展开
    m = x <= 15
    if np.any(m):
        xs = x[m]
        t = xs / 2
        acc = np.zeros_like(xs)
        for k in range(120):
            acc += t
            t *= -xs * xs / (4 * (k + 1) * (k + 2))
            if np.all(np.abs(t) < 1e-14):
                break
        r[m] = acc
    # 大参数: 渐近近似
    if np.any(~m):
        xl = x[~m]
        r[~m] = np.sqrt(2 / (np.pi * xl)) * np.cos(xl - 3 * np.pi / 4)
    return r.item() if is_scalar else r


def _hpbw_1d(theta, Pn):
    """从 1D 功率方向图提取半功率波束宽度 (HPBW)"""
    ab = Pn >= 0.5
    if not np.any(ab):
        return 0.0
    idx = np.where(ab)[0]
    g = np.split(idx, np.where(np.diff(idx) != 1)[0] + 1)
    ml = max(g, key=len) if g else idx
    if len(ml) < 2:
        return 0.0
    w = np.degrees(theta[ml[-1]] - theta[ml[0]])
    if len(ml) < len(idx) and (ml[0] == 0 or ml[-1] == len(theta) - 1):
        w *= 2
    return w


def compute_fov_analysis(hpbw_e_deg, hpbw_h_deg, D_dBi, dish_a, dish_b,
                         shield_D=0.0, shield_H=0.0, dish_f=0.32,
                         use_shield=True, lam=None):
    """计算射电望远镜视角场覆盖范围 (含屏蔽桶物理效应)

    Parameters
    ----------
    hpbw_e_deg : float   E 面半功率波束宽度 (度)
    hpbw_h_deg : float   H 面半功率波束宽度 (度)
    D_dBi : float        指向性 (dBi)
    dish_a, dish_b : float  抛物面口径半轴 (m)
    shield_D : float     屏蔽桶直径 (m), 0=无屏蔽桶
    shield_H : float     屏蔽桶高度 (m)
    dish_f : float       抛物面焦距 (m)
    use_shield : bool    是否启用屏蔽桶
    lam : float          波长 (m), 默认使用 C.LAM

    Returns
    -------
    dict with keys:
        omega_beam_sr       — 自然波束立体角 (sr, 无屏蔽桶)
        omega_beam_sqdeg    — 自然波束立体角 (平方度)
        omega_shield_sr     — 屏蔽桶几何限制立体角 (sr)
        omega_shield_sqdeg  — 屏蔽桶几何限制 (平方度)
        fov_effective_sr    — 有效视角场立体角 (sr, 含屏蔽桶)
        fov_effective_sqdeg — 有效视角场 (平方度)
        shield_rim_deg      — 屏蔽桶边缘角 (度, 几何截止)
        shield_limited      — 屏蔽桶是否限制了视场
        truncation_ratio    — 屏蔽桶对视场的压缩比 (0~1)
        n_beams_sky         — 覆盖全天空所需波束数 (有效)
        n_beams_sky_natural — 覆盖全天空所需波束数 (自然)
        theta_res_deg       — 角分辨率 (度, Rayleigh)
        avg_hpbw_deg        — 平均 HPBW (度)
        cone_half_angle     — 3D圆锥半角 (度, 取有效HPBW/2)
        D_linear            — 指向性 (线性值)
        D_dBi               — 指向性 (dBi)
        D_eff               — 有效口径 (m)
    """
    if lam is None:
        lam = C.LAM

    D_linear = 10 ** (D_dBi / 10)
    D_eff = 2 * np.sqrt(dish_a * dish_b) if dish_a * dish_b > 0 else 1.0
    sqdeg_per_sr = (180 / np.pi) ** 2

    # ── 自然波束 (无屏蔽桶) ──
    omega_beam_sr = 4 * np.pi / D_linear
    omega_beam_sqdeg = omega_beam_sr * sqdeg_per_sr

    # ── 屏蔽桶几何限制 ──
    shield_R = shield_D / 2.0
    if use_shield and shield_R > 1e-9 and shield_H > lam / 20:
        # 屏蔽桶边缘角: 从馈源看到的桶口半张角
        rim_dist = dish_f + shield_H  # 馈源到桶口沿光轴距离
        shield_rim_rad = np.arctan2(shield_R, rim_dist)
        shield_rim_deg = np.degrees(shield_rim_rad)
        # 屏蔽桶几何锥立体角: Ω = 2π(1 - cos(θ_rim))
        omega_shield_sr = 2 * np.pi * (1 - np.cos(shield_rim_rad))
        omega_shield_sqdeg = omega_shield_sr * sqdeg_per_sr

        # 有效 FOV = 自然波束被屏蔽桶截断
        # 若 HPBW 半角 > 屏蔽桶边缘角, 视场被桶限制
        beam_half_rad = np.radians(np.sqrt(hpbw_e_deg * hpbw_h_deg) / 2.0
                                   if hpbw_e_deg > 0 and hpbw_h_deg > 0
                                   else max(hpbw_e_deg, hpbw_h_deg) / 2.0)
        shield_limited = beam_half_rad > shield_rim_rad

        # 有效 FOV 用软截断近似: 自然波束 × 屏蔽桶透射率
        # 屏蔽桶透射率 ≈ (Ω_shield / Ω_beam) 当 Ω_shield < Ω_beam
        if omega_shield_sr < omega_beam_sr:
            # 屏蔽桶是限制因素
            fov_effective_sr = omega_shield_sr * 0.85  # 考虑边缘衍射损耗
            truncation_ratio = fov_effective_sr / omega_beam_sr
        else:
            fov_effective_sr = omega_beam_sr
            truncation_ratio = 1.0

        fov_effective_sqdeg = fov_effective_sr * sqdeg_per_sr

        # 3D cone half-angle: use the effective cutoff
        # If shield-limited, cone ~ shield_rim; else natural HPBW/2
        if shield_limited:
            cone_half_angle = shield_rim_deg * 0.85  # slightly inside rim
        else:
            cone_half_angle = np.sqrt(hpbw_e_deg * hpbw_h_deg) / 2.0
    else:
        # 无屏蔽桶或桶可忽略
        shield_rim_deg = 90.0
        omega_shield_sr = 2 * np.pi  # 半球 (忽略后向)
        omega_shield_sqdeg = omega_shield_sr * sqdeg_per_sr
        fov_effective_sr = omega_beam_sr
        fov_effective_sqdeg = omega_beam_sqdeg
        shield_limited = False
        truncation_ratio = 1.0
        cone_half_angle = (np.sqrt(hpbw_e_deg * hpbw_h_deg) / 2.0
                          if hpbw_e_deg > 0 and hpbw_h_deg > 0
                          else max(hpbw_e_deg, hpbw_h_deg) / 2.0)

    # ── 巡天能力 ──
    full_sky_sr = 4 * np.pi
    n_beams_sky = full_sky_sr / max(fov_effective_sr, 1e-15)
    n_beams_sky_natural = full_sky_sr / max(omega_beam_sr, 1e-15)

    # ── 角分辨率 (Rayleigh) ──
    theta_res_rad = 1.22 * lam / D_eff if D_eff > 1e-9 else np.pi
    theta_res_deg = np.degrees(theta_res_rad)

    avg_hpbw_deg = (np.sqrt(hpbw_e_deg * hpbw_h_deg)
                    if hpbw_e_deg > 0 and hpbw_h_deg > 0
                    else max(hpbw_e_deg, hpbw_h_deg))

    return dict(
        omega_beam_sr=omega_beam_sr,
        omega_beam_sqdeg=omega_beam_sqdeg,
        omega_shield_sr=omega_shield_sr,
        omega_shield_sqdeg=omega_shield_sqdeg,
        fov_effective_sr=fov_effective_sr,
        fov_effective_sqdeg=fov_effective_sqdeg,
        shield_rim_deg=shield_rim_deg,
        shield_limited=shield_limited,
        truncation_ratio=truncation_ratio,
        n_beams_sky=n_beams_sky,
        n_beams_sky_natural=n_beams_sky_natural,
        theta_res_deg=theta_res_deg,
        avg_hpbw_deg=avg_hpbw_deg,
        cone_half_angle=cone_half_angle,
        D_linear=D_linear,
        D_dBi=D_dBi,
        D_eff=D_eff,
        hpbw_e_deg=hpbw_e_deg,
        hpbw_h_deg=hpbw_h_deg,
    )


def compute_metrics(func, length, nt=360, np_=720, **kw):
    """全方位指标: 指向性, HPBW, F/B"""
    t = np.linspace(0, np.pi, nt)
    p = np.linspace(0, 2 * np.pi, np_)
    TH, PH = np.meshgrid(t, p, indexing='ij')
    E = func(TH, PH, length, **kw)
    P = np.abs(E) ** 2
    Pm = np.max(P)
    if Pm <= 0:
        return {'D_dBi': 0, 'HPBW_E': 0, 'HPBW_H': 0, 'FB_dB': 0}
    with np.errstate(divide='ignore', invalid='ignore'):
        try:
            from scipy.integrate import simpson
            Pr = simpson(simpson(P * np.sin(TH), t, axis=0), p)
        except Exception:
            Pr = np.trapz(np.trapz(P * np.sin(TH), t, axis=0), p)
    if Pr <= 0:
        return {'D_dBi': 0, 'HPBW_E': 0, 'HPBW_H': 0, 'FB_dB': 0}
    D = 10 * np.log10(4 * np.pi * Pm / Pr)

    HE = _hpbw_1d(t, np.abs(func(t, np.pi / 2, length, **kw)) ** 2)
    HH = _hpbw_1d(t, np.abs(func(t, 0, length, **kw)) ** 2)

    it = np.argmin(np.abs(t - np.pi / 2))
    ip = np.argmin(np.abs(p - np.pi))
    Pf = np.abs(func(t[it], p[0], length, **kw)) ** 2
    Pb = np.abs(func(t[it], p[ip], length, **kw)) ** 2
    FB = 10 * np.log10(Pf / Pb) if Pb > 0 else 40
    return {'D_dBi': D, 'HPBW_E': HE, 'HPBW_H': HH, 'FB_dB': FB}
