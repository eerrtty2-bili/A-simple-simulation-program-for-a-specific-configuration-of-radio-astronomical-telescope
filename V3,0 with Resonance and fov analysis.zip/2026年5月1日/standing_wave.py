"""
屏蔽桶驻波分析模块: SWR / 反射系数 / 腔体谐振 / 场分布 / 增益抖动
"""

import numpy as np
import constants as C

# 自由空间波阻抗
Z0 = 377.0  # Ω


def _cylindrical_cavity_modes(shield_D, shield_H, freq_start, freq_end):
    """计算圆柱腔 TE/TM 谐振模式频率列表"""
    R = shield_D / 2.0
    if R < 1e-9 or shield_H < 1e-9:
        return []
    c = C.C
    # Bessel 导数零点 x'_mn (TE, n>=1) 及 J_m 零点 x_mn (TM)
    # m=0,1,2; n=1,2,3 — 常用低阶模式
    te_roots = [1.8412, 3.0542, 3.8317, 4.2012, 5.3175, 5.3314]
    tm_roots = [2.4048, 3.8317, 5.1356, 5.5201, 6.3802, 7.0156]

    modes = []
    for p in range(6):
        pz = (p + 0) * np.pi / shield_H
        for ri, root in enumerate(te_roots[:6]):
            f = c / (2 * np.pi) * np.sqrt((root / R) ** 2 + pz ** 2)
            if freq_start * 0.3 <= f <= freq_end * 3.0:
                modes.append((f, f"TE_{ri+1}{p}", root))
        for ri, root in enumerate(tm_roots[:6]):
            f = c / (2 * np.pi) * np.sqrt((root / R) ** 2 + pz ** 2)
            if freq_start * 0.3 <= f <= freq_end * 3.0:
                modes.append((f, f"TM_{ri+1}{p}", root))
    # 去重排序
    seen = set()
    uniq = []
    for f, name, root in sorted(modes, key=lambda x: x[0]):
        key = (round(f / 1e4), name)
        if key not in seen:
            seen.add(key)
            uniq.append((f, name))
    return uniq


def bucket_reflection_coefficient(freq, shield_D, shield_H, dish_f, d_feed_to_dish):
    """屏蔽桶内等效反射系数 (含抛物面终端效应)

    Parameters
    ----------
    freq : float
        频率 (Hz)
    shield_D : float
        桶直径 (m)
    shield_H : float
        桶高度 (m)
    dish_f : float
        抛物面焦距 (m), 用于估计终端反射相位
    d_feed_to_dish : float
        馈源到抛物面顶点的距离 (m)

    Returns
    -------
    Gamma : complex
        馈源端等效反射系数
    """
    lam = C.C / freq
    k = 2 * np.pi / lam
    R = shield_D / 2.0

    if R < 1e-9 or shield_H < 1e-9:
        return 0.0 + 0.0j

    # ---- 抛物面终端反射 ----
    # 抛物面等效阻抗按口径效率估算: 大部分能量被辐射, 小部分反射
    # |Γ_dish| ≈ 0.05~0.2 (实际取决于焦距比 f/D)
    dish_aperture = R  # 近似
    if dish_f > 1e-9:
        fD = dish_f / (2 * dish_aperture) if dish_aperture > 0 else 1.0
    else:
        fD = 1.0
    # 深锅 (f/D 小) 反射更大
    gamma_dish_mag = 0.08 + 0.15 * np.exp(-3.0 * fD)
    # 抛物面顶点反射相位: 往返 2f
    phi_dish = -2 * k * dish_f + np.pi
    Gamma_dish = gamma_dish_mag * np.exp(1j * phi_dish)

    # ---- 桶开口端反射 ----
    # 开口圆波导终端: |Γ_open| ≈ (λ/λ_c)^2 / sqrt(1-(λ/λ_c)^2) for λ>>λ_c
    lambda_c_TE11 = 3.412 * R  # TE11 截止波长
    if lam > lambda_c_TE11 * 0.9:
        gamma_open_mag = 0.6 + 0.3 * (lam - 0.9 * lambda_c_TE11) / (0.1 * lambda_c_TE11)
        gamma_open_mag = min(gamma_open_mag, 0.92)
    else:
        ratio = lam / lambda_c_TE11
        gamma_open_mag = (ratio ** 2) / np.sqrt(max(1 - ratio ** 2, 0.01))
        gamma_open_mag = min(gamma_open_mag, 0.3)
    phi_open = 0.0  # 开口端相位近似
    Gamma_open = gamma_open_mag * np.exp(1j * phi_open)

    # ---- 桶内多次反射合成 ----
    # 桶长 H, 终端为抛物面 + 开口
    # 往返传播: e^(-2jβ H)
    L_eff = shield_H
    roundtrip = np.exp(-2j * k * L_eff)

    # 馈源处总反射 = Γ_dish * e^(-2jβd) + (1-Γ_dish)^2 * Γ_open * e^(-2jβ(H+d)) * ...
    # 使用等比级数求和近似
    d_rt = d_feed_to_dish
    phase_to_dish = np.exp(-2j * k * d_rt)
    phase_roundtrip = np.exp(-2j * k * (d_rt + L_eff))

    Gamma_direct = Gamma_dish * phase_to_dish

    # 从馈源发出的波经抛物面→开口→抛物面→馈源 的往返
    cascade = Gamma_open * roundtrip
    # 1 + x + x² + ... = 1/(1-x)
    if abs(cascade * Gamma_dish) < 1.0:
        fabry_perot = 1.0 / (1.0 - cascade * np.conj(Gamma_dish))
    else:
        fabry_perot = 1.0

    Gamma_total = Gamma_direct + (1.0 - gamma_dish_mag ** 2) * Gamma_open * phase_roundtrip * fabry_perot

    return Gamma_total


def swr_from_gamma(Gamma):
    """|Γ| → VSWR"""
    mag = abs(Gamma)
    if mag >= 1.0:
        return 1e6  # 无穷大替代(完全反射)
    return (1.0 + mag) / (1.0 - mag)


def return_loss_from_gamma(Gamma):
    """|Γ| → 回波损耗 (dB)"""
    mag = abs(Gamma)
    if mag < 1e-15:
        return 60.0
    return -20 * np.log10(mag)


def mismatch_loss_from_Gamma(Gamma):
    """反射系数 → 失配损耗 (dB), ML = -10*log10(1-|Γ|²)"""
    mag2 = abs(Gamma) ** 2
    if mag2 >= 1.0:
        return 60.0
    return -10 * np.log10(max(1.0 - mag2, 1e-20))


def standing_wave_field_axial(z_array, Gamma, freq=None):
    """馈源-抛物面轴线上的归一化驻波电场幅值

    E(z) ∝ |e^{-jβz} + Γ·e^{+jβz}|
    其中 z 从馈源位置(z=0)向抛物面方向为正
    """
    if freq is None:
        freq = C.FREQ
    k = 2 * np.pi * freq / C.C
    z = np.asarray(z_array, dtype=float)
    E = np.abs(np.exp(-1j * k * z) + Gamma * np.exp(1j * k * z))
    return E


def compute_swr_sweep(shield_D, shield_H, dish_f, d_feed_to_dish,
                      freq_start=None, freq_end=None, n_pts=500):
    """频率扫描: 计算 SWR / 回波损耗 / 失配损耗 vs 频率"""
    if freq_start is None:
        freq_start = 500e6
    if freq_end is None:
        freq_end = 3000e6
    freqs = np.linspace(freq_start, freq_end, n_pts)
    swr_arr = np.empty(n_pts)
    rl_arr = np.empty(n_pts)
    ml_arr = np.empty(n_pts)
    gamma_mag_arr = np.empty(n_pts)

    for i, f in enumerate(freqs):
        G = bucket_reflection_coefficient(f, shield_D, shield_H, dish_f, d_feed_to_dish)
        swr_arr[i] = swr_from_gamma(G)
        rl_arr[i] = return_loss_from_gamma(G)
        ml_arr[i] = mismatch_loss_from_Gamma(G)
        gamma_mag_arr[i] = abs(G)

    return freqs, swr_arr, rl_arr, ml_arr, gamma_mag_arr


def compute_swr_summary(shield_D, shield_H, dish_f, d_feed_to_dish,
                        freq_start=500e6, freq_end=3000e6, n_pts=400):
    """驻波分析汇总: 中心频率 SWR + 频带内统计"""
    f0 = C.FREQ
    G0 = bucket_reflection_coefficient(f0, shield_D, shield_H, dish_f, d_feed_to_dish)
    swr0 = swr_from_gamma(G0)
    rl0 = return_loss_from_gamma(G0)
    ml0 = mismatch_loss_from_Gamma(G0)

    # 频带扫描
    freqs, swr, rl, ml, gm = compute_swr_sweep(
        shield_D, shield_H, dish_f, d_feed_to_dish, freq_start, freq_end, n_pts)

    # 频带内统计
    swr_max = np.max(swr[np.isfinite(swr)])
    rl_min = np.min(rl[np.isfinite(rl)])
    ml_max = np.max(ml[np.isfinite(ml)])

    # 谐振模式
    modes = _cylindrical_cavity_modes(shield_D, shield_H, freq_start, freq_end)

    # 查找 SWR 峰值频率 (谐振点)
    peak_mask = np.zeros(len(freqs), dtype=bool)
    for k in range(2, len(freqs) - 2):
        if swr[k] > 5 and swr[k] > swr[k - 2] and swr[k] > swr[k + 2]:
            peak_mask[k] = True
    swr_peaks = list(zip(freqs[peak_mask], swr[peak_mask]))

    return dict(
        freq_center=f0,
        swr=swr0,
        return_loss=rl0,
        mismatch_loss=ml0,
        gamma_mag=abs(G0),
        gamma_phase=np.angle(G0, deg=True),
        swr_max_in_band=swr_max,
        rl_min_in_band=rl_min,
        ml_max_in_band=ml_max,
        freq_sweep=freqs,
        swr_sweep=swr,
        rl_sweep=rl,
        ml_sweep=ml,
        gamma_sweep=gm,
        cavity_modes=modes,
        swr_peaks=swr_peaks,
    )


def field_distribution_2d(z_range, r_range, shield_D, shield_H,
                          dish_f, d_feed_to_dish, freq=None, nz=200, nr=80):
    """桶内 z-r 平面的归一化驻波场幅值分布

    Parameters
    ----------
    nz : int
        z 方向采样点数
    nr : int
        r 方向采样点数
    """
    """桶内 z-r 平面的归一化驻波场幅值分布"""
    if freq is None:
        freq = C.FREQ
    R = shield_D / 2.0
    if R < 1e-9:
        return None, None, np.zeros((1, 1))

    lam = C.C / freq
    k = 2 * np.pi / lam

    G = bucket_reflection_coefficient(freq, shield_D, shield_H, dish_f, d_feed_to_dish)

    z = np.linspace(z_range[0], z_range[1], nz)
    r = np.linspace(r_range[0], min(r_range[1], R), nr)
    Z, Rgrid = np.meshgrid(z, r, indexing='ij')

    kc_TE11 = 1.8412 / R
    if has_j1():
        from scipy.special import j1
        radial = np.where(Rgrid <= R, j1(kc_TE11 * np.clip(Rgrid, 1e-12, R)), 0.0)
    else:
        radial = np.where(Rgrid <= R, np.sin(np.pi * Rgrid / R), 0.0)

    axial = np.abs(np.exp(-1j * k * Z) + G * np.exp(1j * k * Z))
    field = radial * axial

    mx = np.max(field)
    if mx > 0:
        field /= mx
    return Z, Rgrid, field


def has_j1():
    try:
        from scipy.special import j1
        return True
    except ImportError:
        return False
