"""
方向图渲染视图: 独立的绘图函数,返回 matplotlib Figure 对象
"""

import tkinter as tk
import numpy as np
import matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt
from matplotlib.figure import Figure
from matplotlib.gridspec import GridSpec
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from matplotlib.lines import Line2D

import constants as C
from rendering import render_structure, render_overlay
from pattern import pattern_ray_trace, pattern_bare
from math_utils import _hpbw_1d, compute_fov_analysis
from geometry import _offset_axis


def embed_figure(fig, parent, root):
    """嵌入 matplotlib Figure 到 tkinter 框架"""
    for w in parent.winfo_children():
        w.destroy()
    c = FigureCanvasTkAgg(fig, master=parent)
    c.draw()
    c.get_tk_widget().pack(fill=tk.BOTH, expand=True)
    t_ = NavigationToolbar2Tk(c, parent, pack_toolbar=False)
    t_.update()
    t_.pack(side=tk.BOTTOM, fill=tk.X)


def _normalize(arr):
    arr = np.asarray(arr, dtype=float)
    mx = np.max(arr)
    return arr / mx if mx > 0 else arr


def _polar_radius(arr, floor=-30):
    """线性归一化方向图 → 极坐标半径 0~1"""
    p = _normalize(np.abs(arr))
    return 10 ** (np.clip(10 * np.log10(np.clip(p, 1e-10, None)), floor, 0) / 20)


def _rect_scale_db(arr, floor=-40):
    """直角坐标 dB 曲线值 (dB)"""
    p = _normalize(np.abs(arr))
    return np.clip(10 * np.log10(np.clip(p, 1e-10, None)), floor, 0)


# ======================== 极坐标方向图 ========================

def render_polar(dip_type_name, t_fine, E_e, E_h, metrics):
    fig = Figure(figsize=(7, 6), dpi=100)
    fig.suptitle(f"{dip_type_name} — 全金属模型", fontsize=12, fontweight="bold")

    ax0 = fig.add_subplot(1, 2, 1, projection='polar')
    ax0.plot(t_fine, _polar_radius(E_e), '#00bc8c', lw=1.5)
    ax0.set_title("E 面 (φ=90°)", va="bottom", fontsize=10)
    ax0.set_ylim(0, 1.05)
    ax0.grid(True, alpha=0.3)
    h = metrics.get('HPBW_E', 0)
    if h > 0:
        hh = np.radians(h / 2)
        ax0.plot([np.pi - hh, np.pi + hh], [0.707, 0.707], 'r--', lw=1.5, alpha=0.7)
        ax0.annotate(f"HPBW={h:.1f}°", xy=(np.pi, 0.85), fontsize=9, color='red', ha='center')

    ax1 = fig.add_subplot(1, 2, 2, projection='polar')
    ax1.plot(t_fine, _polar_radius(E_h), '#e67e22', lw=1.5)
    ax1.set_title("H 面 (φ=180° 主瓣)", va="bottom", fontsize=10)
    ax1.set_ylim(0, 1.05)
    ax1.grid(True, alpha=0.3)
    h = metrics.get('HPBW_H', 0)
    if 10 < h < 170:
        hh = np.radians(h / 2)
        ax1.plot([np.pi - hh, np.pi + hh], [0.707, 0.707], 'r--', lw=1.5, alpha=0.7)
        ax1.annotate(f"HPBW={h:.1f}°", xy=(np.pi, 0.85), fontsize=9, color='red', ha='center')

    fig.tight_layout()
    return fig


# ======================== 3D 方向图 ========================

def render_3d(dip_type_name, t_2d, p_2d_array, E_2d):
    fig = Figure(figsize=(8, 7), dpi=100)
    ax = fig.add_subplot(111, projection='3d')
    TH, PH = np.meshgrid(t_2d, p_2d_array, indexing='ij')
    P = _normalize(np.abs(E_2d))
    Pd = np.clip(10 * np.log10(np.clip(P, 1e-10, None)), -20, 0)
    n = plt.Normalize(-20, 0)
    c = plt.cm.viridis(n(Pd))
    R = P
    X = R * np.sin(TH) * np.cos(PH)
    Y = R * np.sin(TH) * np.sin(PH)
    Z = R * np.cos(TH)
    ax.plot_surface(X, Y, Z, facecolors=c, rstride=1, cstride=1, alpha=0.9, lw=0)
    u, v = np.mgrid[0:2 * np.pi:20j, 0:np.pi:10j]
    ax.plot_wireframe(0.3 * np.sin(u) * np.cos(v), 0.3 * np.sin(u) * np.sin(v),
                      0.3 * np.cos(u), color='gray', alpha=0.06, lw=0.3)
    ax.set_xlim(-1.1, 1.1)
    ax.set_ylim(-1.1, 1.1)
    ax.set_zlim(-1.1, 1.1)
    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_zlabel('Z')
    ax.set_title(f"{dip_type_name} — 全金属模型", fontsize=11, fontweight="bold")
    for a_ in [ax.xaxis, ax.yaxis, ax.zaxis]:
        a_.pane.fill = False
    ax.set_xticks([])
    ax.set_yticks([])
    ax.set_zticks([])
    m = plt.cm.ScalarMappable(norm=n, cmap=plt.cm.viridis)
    m.set_array([])
    fig.colorbar(m, ax=ax, shrink=0.6, pad=0.1).set_label('归一化方向图 (dB)', fontsize=9)
    fig.tight_layout()
    return fig


# ======================== 天线结构 ========================

def render_structure_view(length, params, qr):
    """天线结构 3D 视图, params 是 var_d 的 get() 快照 (包含 show_struct)"""
    fig = Figure(figsize=(8, 7), dpi=100)
    ax = fig.add_subplot(111, projection='3d')
    render_structure(ax, length,
                     params['dish_a'], params['dish_b'], params['dish_f'],
                     params['offset_ang'],
                     params.get('show_shield', True), params['can_D'], params['can_H'],
                     params['cyl_R'], params['cyl_L'], params['cyl_ang'],
                     params['feed_dx'], params['feed_dz'],
                     params.get('can_rot_x', 0), params.get('can_rot_y', 0),
                     nr=qr['dish_nr'] if qr else 20,
                     np_=qr['dish_np'] if qr else 30,
                     cyl_nu=qr['cyl_nu'] if qr else 36,
                     cyl_nv=qr['cyl_nv'] if qr else 28,
                     show_dish=params.get('use_dish', True),
                     show_reflector=params.get('use_reflector', True))
    parts = ['偶极子']
    if params.get('use_dish', True):
        parts.append('抛物面锅')
    if params.get('use_reflector', True):
        parts.append('半圆柱反射板')
    if params.get('show_shield', True):
        parts.append('屏蔽桶')
    ax.set_title("天线结构: " + " + ".join(parts), fontsize=11, fontweight="bold")
    h = [Line2D([0], [0], color='blue', lw=3, label='偶极子')]
    if params.get('use_reflector', True):
        h.append(Line2D([0], [0], color='gold', lw=6, alpha=0.4, label='半圆柱反射板'))
    if params.get('use_dish', True):
        h.append(Line2D([0], [0], color='silver', lw=1, alpha=0.4, label='抛物面锅'))
    if params.get('show_shield', True):
        h.append(Line2D([0], [0], color='gray', lw=1, alpha=0.4, label='屏蔽桶'))
    if len(h) > 1:
        ax.legend(handles=h, loc='upper right', fontsize=7)
    fig.tight_layout()
    return fig


# ======================== 叠加视图 ========================

def render_overlay_view(t, p_, Ep, params, length):
    """结构 + 方向图叠加"""
    fig = Figure(figsize=(9, 8), dpi=100)
    ax = fig.add_subplot(111, projection='3d')
    render_overlay(ax, t, p_, Ep,
                   params['dish_a'], params['dish_b'], params['dish_f'],
                   params['offset_ang'],
                   params.get('show_shield', True), params['can_D'], params['can_H'],
                   params['cyl_R'], params['cyl_L'], params['cyl_ang'],
                   length, params['feed_dx'], params['feed_dz'],
                   params.get('can_rot_x', 0), params.get('can_rot_y', 0),
                   show_dish=params.get('use_dish', True),
                   show_reflector=params.get('use_reflector', True))
    ax.set_title("结构 + 方向图叠加 (颜色=增益强度)", fontsize=11, fontweight="bold")
    Pn = _normalize(np.abs(Ep))
    n_ = plt.Normalize(0, 1)
    m_ = plt.cm.ScalarMappable(norm=n_, cmap=plt.cm.hot)
    m_.set_array([])
    fig.colorbar(m_, ax=ax, shrink=0.5, pad=0.1).set_label('归一化增益', fontsize=9)
    fig.tight_layout()
    return fig


# ======================== 点源增益分析 ========================

def render_point_source(t_1d, t_2d, p_2d, E_2d, E_e, E_h, metrics, params,
                        dip_type_name, length, stage_data=None):
    """点源增益分析: 4级渐进结构分解 (由近及远)"""
    fig = Figure(figsize=(12, 8.5), dpi=100)
    gs = GridSpec(2, 3, figure=fig, height_ratios=[3.5, 2.5])

    # ===== (0,0) 3D 最终方向图 =====
    ax_3d = fig.add_subplot(gs[0, 0], projection='3d')
    TH, PH = np.meshgrid(t_2d, p_2d, indexing='ij')
    P = _normalize(np.abs(E_2d))
    Pd = np.clip(10 * np.log10(np.clip(P, 1e-10, None)), -20, 0)
    n_cmap = plt.Normalize(-20, 0)
    colors = plt.cm.viridis(n_cmap(Pd))
    R = P
    X = R * np.sin(TH) * np.cos(PH)
    Y = R * np.sin(TH) * np.sin(PH)
    Z = R * np.cos(TH)
    ax_3d.plot_surface(X, Y, Z, facecolors=colors, rstride=1, cstride=1, alpha=0.9, lw=0)
    ax_3d.scatter([0], [0], [0], color='red', s=120, marker='o', zorder=10, label='点源馈点')
    ax_3d.text(0, 0, 0.05, ' 馈点', color='red', fontsize=9, fontweight='bold')
    ax_3d.set_xlim(-1.1, 1.1); ax_3d.set_ylim(-1.1, 1.1); ax_3d.set_zlim(-1.1, 1.1)
    ax_3d.set_xlabel('X'); ax_3d.set_ylabel('Y'); ax_3d.set_zlabel('Z')
    ax_3d.set_title("最终方向图 (全结构)", fontsize=10, fontweight="bold")
    for a_ in [ax_3d.xaxis, ax_3d.yaxis, ax_3d.zaxis]:
        a_.pane.fill = False
    ax_3d.set_xticks([]); ax_3d.set_yticks([]); ax_3d.set_zticks([])
    ax_3d.legend(fontsize=7, loc='upper right')
    m_sm = plt.cm.ScalarMappable(norm=n_cmap, cmap=plt.cm.viridis)
    m_sm.set_array([])
    fig.colorbar(m_sm, ax=ax_3d, shrink=0.5, pad=0.05).set_label('归一化增益 (dB)', fontsize=7)

    # ===== 4 级渐进极坐标图 + 指标表 =====
    if stage_data:
        polar_pos = [(0, 1), (0, 2), (1, 0), (1, 1)]
        c_plane = ['#00bc8c', '#e67e22']
        for idx, sd in enumerate(stage_data):
            row, col = polar_pos[idx]
            ax = fig.add_subplot(gs[row, col], projection='polar')
            ax.plot(t_1d, _polar_radius(sd['E_e'], floor=-30), c_plane[0], lw=1.5, label='E面')
            ax.plot(t_1d, _polar_radius(sd['E_h'], floor=-30), c_plane[1], lw=1.5, label='H面')
            ax.set_ylim(0, 1.05); ax.grid(True, alpha=0.3)
            ax.set_title(sd['name'], fontsize=9, fontweight="bold", pad=8)
            for key, clr in [('HPBW_E', '#00bc8c'), ('HPBW_H', '#e67e22')]:
                h = sd.get(key, 0)
                if 10 < h < 170:
                    hh = np.radians(h / 2)
                    ax.plot([np.pi - hh, np.pi + hh], [0.707, 0.707],
                            color=clr, ls='--', lw=1, alpha=0.6)
            if idx == 0:
                ax.legend(fontsize=6, loc='upper right')
        # 指标演进表
        ax_t = fig.add_subplot(gs[1, 2])
        ax_t.axis('off')
        tbl_d = [[sd['name'], f"{sd['D_dBi']:.1f}", f"{sd['HPBW_E']:.1f}°",
                  f"{sd['HPBW_H']:.1f}°", f"{sd['FB_dB']:.1f}"] for sd in stage_data]
        tbl = ax_t.table(cellText=tbl_d,
            colLabels=['阶段', 'D(dBi)', 'HPBW_E', 'HPBW_H', 'F/B(dB)'],
            loc='center', cellLoc='center', colWidths=[0.24, 0.14, 0.14, 0.14, 0.16])
        tbl.auto_set_font_size(False); tbl.set_fontsize(8); tbl.scale(1, 1.9)
        for j in range(5):
            tbl[0, j].set_facecolor('#094771')
            tbl[0, j].set_text_props(color='white', fontweight='bold')
        for i in range(1, 5):
            tbl[i, 0].set_facecolor('#2d2d2d')
        ax_t.set_title("指标演进 (逐级叠加)", fontsize=10, fontweight="bold", pad=12)
    else:
        ax_fb = fig.add_subplot(gs[:, 1:])
        ax_fb.axis('off')
        ax_fb.text(0.5, 0.5, "计算阶段数据中...\n请重新运行仿真",
                  ha='center', va='center', fontsize=12, color='#888888')

    fig.suptitle("点源增益分析 — 4级渐进结构分解 (由近及远)",
                fontsize=12, fontweight="bold", y=0.98)
    fig.tight_layout(rect=[0, 0, 1, 0.96])
    return fig


# ======================== 配置对比 ========================

def render_comparison(params, dip_type_name, length):
    """多口径对比: 0.8× / 1.0× / 1.2×"""
    a = params['dish_a']
    b = params['dish_b']
    f = params['dish_f']
    d0 = params['ref_dist']
    feed_dx = params['feed_dx']
    feed_dz = params['feed_dz']
    shield_D = params['can_D']
    shield_H = params['can_H']
    oa = params['offset_ang']
    ur = params.get('use_reflector', True)
    ud = params.get('use_dish', True)
    us = params.get('use_shield', True)

    scales = [0.8, 1.0, 1.2]
    D0 = 2 * np.sqrt(a * b)
    Ds = [D0 * s for s in scales]
    nm = [f"D={D:.2f}m" for D in Ds]

    def _mm():
        results = []
        tf = np.linspace(0, np.pi, 360)
        for s in scales:
            aa = a * s
            bb = b * s
            def rt(t, p, L, dd=aa, ee=bb):
                return pattern_ray_trace(t, p, L, d0, dd, ee, f,
                    feed_dx, feed_dz, shield_D,
                    shield_H=shield_H, offset_ang=oa,
                    use_reflector=ur, use_dish=ud, use_shield=us)
            D_dBi = 10 * np.log10(4 * np.pi * 0.55 * np.pi * aa * bb / C.LAM**2)
            Ee = np.abs(rt(tf, np.pi / 2, length))
            Eh = np.abs(rt(tf, np.pi, length))
            pe = _normalize(Ee)
            ph = _normalize(Eh)
            he = _hpbw_1d(tf, pe**2)
            hh = _hpbw_1d(tf, ph**2)
            bs_t = np.radians(60)
            Pf = np.abs(rt(bs_t, np.pi, length))**2
            Pb = np.abs(rt(np.pi - bs_t, 0.0, length))**2
            fb = 10 * np.log10(Pf / Pb) if Pb > 0 else 40.0
            results.append({'D_dBi': D_dBi, 'HPBW_E': he, 'HPBW_H': hh, 'FB_dB': fb})
        return results
    mm = _mm()

    fig = Figure(figsize=(12, 13), dpi=100)
    gs = GridSpec(3, 3, figure=fig, hspace=0.35, wspace=0.3)
    fig.suptitle("1420 MHz PO 光线追踪 — 口径对比", fontsize=14, fontweight="bold")
    cl = ['#00bc8c', '#3498db', '#e67e22']
    th = np.linspace(0, 2 * np.pi, 720)

    # E面
    ax_e = fig.add_subplot(gs[0, 0], projection='polar')
    for i, s in enumerate(scales):
        aa = a * s; bb = b * s
        def _po(t, p, dd=aa, ee=bb):
            return pattern_ray_trace(t, p, length, d0, dd, ee, f,
                feed_dx, feed_dz, shield_D,
                shield_H=shield_H, offset_ang=oa,
                use_reflector=ur, use_dish=ud, use_shield=us)
        E = np.abs(_po(th, np.pi / 2))
        ax_e.plot(th, _polar_radius(E), color=cl[i], lw=1.2, label=nm[i])
    ax_e.set_title("E 面 (φ=90°)", fontsize=10)
    ax_e.set_ylim(0, 1.05)
    ax_e.legend(fontsize=7)

    # H面
    ax_h = fig.add_subplot(gs[0, 1], projection='polar')
    for i, s in enumerate(scales):
        aa = a * s; bb = b * s
        def _po(t, p, dd=aa, ee=bb):
            return pattern_ray_trace(t, p, length, d0, dd, ee, f,
                feed_dx, feed_dz, shield_D,
                shield_H=shield_H, offset_ang=oa,
                use_reflector=ur, use_dish=ud, use_shield=us)
        E = np.abs(_po(th, 0))
        ax_h.plot(th, _polar_radius(E), color=cl[i], lw=1.2, label=nm[i])
    ax_h.set_title("H 面 (φ=0)", fontsize=10)
    ax_h.set_ylim(0, 1.05)
    ax_h.legend(fontsize=7)

    # 指标对比表
    ax_t = fig.add_subplot(gs[0, 2])
    ax_t.axis('off')
    d_ = [[nm[i], f"{mm[i]['D_dBi']:.1f}", f"{mm[i]['HPBW_E']:.0f}°",
           f"{mm[i]['HPBW_H']:.0f}°", f"{mm[i]['FB_dB']:.1f}"] for i in range(3)]
    t_ = ax_t.table(cellText=d_,
                    colLabels=["口径", "D(dBi)", "HPBW_E", "HPBW_H", "F/B(dB)"],
                    loc='center', cellLoc='center', colWidths=[0.22, 0.16, 0.16, 0.16, 0.16])
    t_.auto_set_font_size(False)
    t_.set_fontsize(9)
    t_.scale(1, 1.8)
    ax_t.set_title("指标对比", fontsize=11, fontweight="bold", pad=20)

    # 增益 vs 口径
    ax_g = fig.add_subplot(gs[1, :])
    Dr = np.linspace(0.3, 1.0, 20)
    gs_plot = [10 * np.log10(4 * np.pi * 0.55 * np.pi * (d / 2)**2 / C.LAM**2) for d in Dr]
    ax_g.plot(Dr, gs_plot, '#e74c3c', lw=2)
    ax_g.set_xlabel("有效口径 D (m)", fontsize=10)
    ax_g.set_ylabel("指向性 (dBi)", fontsize=10)
    ax_g.set_title("PO 模型增益 vs 口径 (理论极限)", fontsize=11, fontweight="bold")
    ax_g.grid(True, alpha=0.3)

    # 频率-增益扫频
    ax_f = fig.add_subplot(gs[2, :])
    f_sweep = np.logspace(np.log10(0.5), np.log10(1700), 300)
    for i, s in enumerate(scales):
        aa_s = a * s; bb_s = b * s
        D_sweep = [10 * np.log10(4 * np.pi * 0.55 * np.pi * aa_s * bb_s /
                                 (C.C / (f_mhz * 1e6))**2) for f_mhz in f_sweep]
        ax_f.semilogx(f_sweep, D_sweep, color=cl[i], lw=1.5, label=nm[i])
    ax_f.axvline(C.FREQ / 1e6, color='gray', ls='--', lw=0.8, alpha=0.5)
    ax_f.annotate(f"{C.FREQ/1e6:.0f} MHz\n(当前)", xy=(C.FREQ/1e6, 0),
                 fontsize=8, color='gray', ha='center', va='bottom')
    ax_f.set_xlabel("频率 (MHz)", fontsize=10)
    ax_f.set_ylabel("指向性 (dBi)", fontsize=10)
    ax_f.set_title("同一天线 — 频率 vs 最大增益/指向性 (理论极限)",
                   fontsize=11, fontweight="bold")
    ax_f.legend(fontsize=8)
    ax_f.grid(True, alpha=0.3, which='both')
    fig.tight_layout()
    return fig


# ======================== 导出报告 ========================

def render_export_report(params, dip_type_name, length, save_path, qr):
    """导出完整报告 (另存为 PNG/PDF)"""
    a = params['dish_a']
    b = params['dish_b']
    f = params['dish_f']
    d_ref = params['ref_dist']
    feed_dx = params['feed_dx']
    feed_dz = params['feed_dz']
    shield_D = params['can_D']
    shield_H = params['can_H']
    oa = params['offset_ang']
    rx = params.get('can_rot_x', 0)
    ry = params.get('can_rot_y', 0)
    ur = params.get('use_reflector', True)
    ud = params.get('use_dish', True)
    us = params.get('use_shield', True)
    show_shield = params.get('show_shield', True)

    def rt(t, p, L):
        return pattern_ray_trace(t, p, L, d_ref, a, b, f,
            feed_dx, feed_dz, shield_D, shield_H=shield_H,
            offset_ang=oa, n_uv=60,
            use_reflector=ur, use_dish=ud, use_shield=us)

    th = np.linspace(0, np.pi, qr['n_pol'])
    Ee = np.abs(rt(th, np.pi / 2, length))
    Eh = np.abs(rt(th, np.pi, length))
    Pe = _normalize(Ee)
    Ph = _normalize(Eh)

    D_dBi = 10 * np.log10(4 * np.pi * 0.55 * np.pi * a * b / C.LAM**2)
    hpbw_e = _hpbw_1d(th, Pe**2)
    hpbw_h = _hpbw_1d(th, Ph**2)
    bs_t = np.radians(60)
    Pf = np.abs(rt(bs_t, np.pi, length))**2
    Pb = np.abs(rt(np.pi - bs_t, 0.0, length))**2
    fb = 10 * np.log10(Pf / Pb) if Pb > 0 else 40.0

    fig = Figure(figsize=(16, 24), dpi=120)
    gs = GridSpec(4, 2, figure=fig, height_ratios=[2, 2, 1.4, 1.4])

    # (0,0) 极坐标方向图
    a0 = fig.add_subplot(gs[0, 0], projection='polar')
    a0.plot(th, _polar_radius(Ee), '#00bc8c', lw=1.2, label='E 面 (φ=90°)')
    a0.plot(th, _polar_radius(Eh), '#e67e22', lw=1.2, label='H 面 (φ=180° 主瓣)')
    a0.set_ylim(0, 1.05)
    a0.grid(True, alpha=0.3)
    a0.set_title("极坐标方向图", fontsize=12, fontweight="bold", pad=12)
    a0.legend(loc='upper right', fontsize=8, bbox_to_anchor=(1.3, 1.0))
    if hpbw_e > 0:
        hh = np.radians(hpbw_e / 2)
        a0.plot([np.pi - hh, np.pi + hh], [0.707] * 2, 'b--', lw=1.5, alpha=0.5)
        a0.annotate(f"E HPBW={hpbw_e:.1f}°", xy=(np.pi, 0.8), fontsize=8, color='blue', ha='center')
    if hpbw_h > 0:
        hh = np.radians(hpbw_h / 2)
        a0.plot([np.pi - hh, np.pi + hh], [0.707] * 2, 'r--', lw=1.5, alpha=0.5)
        a0.annotate(f"H HPBW={hpbw_h:.1f}°", xy=(np.pi, 0.7), fontsize=8, color='red', ha='center')

    # (0,1) 3D 方向图
    a1 = fig.add_subplot(gs[0, 1], projection='3d')
    t3 = np.linspace(0, np.pi, qr['n_3d_t'])
    p3 = np.linspace(0, 2 * np.pi, qr['n_3d_p'])
    T3, P3 = np.meshgrid(t3, p3, indexing='ij')
    E3 = np.abs(rt(T3, P3, length))
    P3d = _normalize(E3)
    Pd = np.clip(10 * np.log10(np.clip(P3d, 1e-10, None)), -20, 0)
    n_c = plt.Normalize(-20, 0)
    c_c = plt.cm.viridis(n_c(Pd))
    R3 = P3d
    X3 = R3 * np.sin(T3) * np.cos(P3)
    Y3 = R3 * np.sin(T3) * np.sin(P3)
    Z3 = R3 * np.cos(T3)
    a1.plot_surface(X3, Y3, Z3, facecolors=c_c, rstride=2, cstride=2, alpha=0.9, lw=0)
    a1.set_xlim(-1.1, 1.1)
    a1.set_ylim(-1.1, 1.1)
    a1.set_zlim(-1.1, 1.1)
    a1.set_title("3D 方向图", fontsize=12, fontweight="bold")
    for ax_ in [a1.xaxis, a1.yaxis, a1.zaxis]:
        ax_.pane.fill = False
    a1.set_xticks([]); a1.set_yticks([]); a1.set_zticks([])

    # (1,0) 天线结构
    a2 = fig.add_subplot(gs[1, 0], projection='3d')
    render_structure(a2, length, a, b, f, oa, show_shield, shield_D, shield_H,
                     params['cyl_R'], params['cyl_L'], params['cyl_ang'],
                     feed_dx, feed_dz, rx, ry,
                     show_dish=ud, show_reflector=ur)
    a2.set_title("天线结构", fontsize=12, fontweight="bold")

    # (1,1) 叠加视图
    a3 = fig.add_subplot(gs[1, 1], projection='3d')
    t_ = np.linspace(0, np.pi, qr['n_3d_t'])
    p_ = np.linspace(0, 2 * np.pi, qr['n_3d_p'])
    TT, PP = np.meshgrid(t_, p_, indexing='ij')
    Ep = rt(TT, PP, length)
    render_overlay(a3, t_, p_, Ep, a, b, f, oa, show_shield, shield_D, shield_H,
                   params['cyl_R'], params['cyl_L'], params['cyl_ang'],
                   length, feed_dx, feed_dz, rx, ry,
                   show_dish=ud, show_reflector=ur)
    a3.set_title("结构 + 方向图叠加", fontsize=12, fontweight="bold")

    # (2,0) 指标汇总
    a4 = fig.add_subplot(gs[2, 0])
    a4.axis('off')
    txt = (f"频率: {C.FREQ/1e6:.1f} MHz  λ={C.LAM*100:.1f} cm\n"
           f"偶极子: {dip_type_name}  L={length*1000:.1f} mm\n"
           f"锅: a={a*100:.1f}cm b={b*100:.1f}cm  f={f*100:.1f}cm\n"
           f"偏馈角: {oa:.1f}°  反射板距离: {d_ref*100:.1f}cm\n"
           f"桶: D={shield_D*100:.1f}cm  H={shield_H*100:.1f}cm\n"
           f"旋转: X={rx:.1f}°  Y={ry:.1f}°\n\n"
           f"✦ 指向性: {D_dBi:.2f} dBi\n"
           f"✦ E面 HPBW: {hpbw_e:.1f}°\n"
           f"✦ H面 HPBW: {hpbw_h:.1f}°\n"
           f"✦ 前后比 F/B: {fb:.1f} dB\n"
           f"✦ 有效口径: {2 * np.sqrt(a * b):.3f}m  "
           f"f/D={(f / (2 * np.sqrt(a * b)) if a * b > 0 else 0):.3f}")
    a4.text(0.05, 0.95, txt, transform=a4.transAxes,
           fontsize=13, va='top', color='#d4d4d4',
           bbox=dict(boxstyle='round', facecolor='#2d2d2d',
                     edgecolor='#666666', alpha=0.95, pad=0.6))

    # (2,1) 增益 vs 口径
    a5 = fig.add_subplot(gs[2, 1])
    Dr = np.linspace(0.3, 1.0, 50)
    G = [10 * np.log10(4 * np.pi * 0.55 * np.pi * (d / 2)**2 / C.LAM**2) for d in Dr]
    a5.plot(Dr, G, '#e74c3c', lw=2)
    if a * b > 0:
        D_eff = 2 * np.sqrt(a * b)
        G_pt = 10 * np.log10(4 * np.pi * 0.55 * np.pi * (D_eff / 2)**2 / C.LAM**2)
        a5.plot(D_eff, G_pt, 'bo', markersize=8)
        a5.annotate(f"当前 D={D_eff:.2f}m\nG={G_pt:.1f}dBi",
                   xy=(D_eff, G_pt), fontsize=9, color='blue',
                   xytext=(5, 5), textcoords='offset points')
    a5.set_xlabel("有效口径 D (m)", fontsize=10)
    a5.set_ylabel("指向性 (dBi)", fontsize=10)
    a5.set_title("增益 vs 口径 (理论极限)", fontsize=11, fontweight="bold")
    a5.grid(True, alpha=0.3)

    custom_len_mm = params.get('custom_len', 0)
    dipole_label = dip_type_name
    if custom_len_mm > 0:
        dipole_label += f" (自定义{length*1000:.1f}mm)"
    comp_parts = []
    if ud: comp_parts.append('抛物面')
    if ur: comp_parts.append('反射板')
    if us: comp_parts.append('屏蔽桶')
    comp_str = " + ".join(comp_parts) if comp_parts else "裸偶极子"

    # (3,:) 频率-增益扫频
    a6 = fig.add_subplot(gs[3, :])
    f_sweep = np.logspace(np.log10(0.5), np.log10(1700), 300)
    D_sweep = [10 * np.log10(4 * np.pi * 0.55 * np.pi * a * b /
                             (C.C / (f_mhz * 1e6))**2) for f_mhz in f_sweep]
    a6.semilogx(f_sweep, D_sweep, '#00bc8c', lw=2)
    a6.axvline(C.FREQ / 1e6, color='gray', ls='--', lw=1, alpha=0.5)
    a6.annotate(f"{C.FREQ/1e6:.0f} MHz (当前)", xy=(C.FREQ/1e6, 0),
               fontsize=9, color='gray', ha='center', va='bottom')
    a6.set_xlabel("频率 (MHz)", fontsize=11)
    a6.set_ylabel("指向性 (dBi)", fontsize=11)
    a6.set_title("频率 vs 最大增益 / 指向性 (理论极限)",
                 fontsize=12, fontweight="bold")
    a6.grid(True, alpha=0.3, which='both')

    fig.suptitle(f"{C.FREQ/1e6:.1f} MHz 天线仿真报告 — {dipole_label} | {comp_str}",
                fontsize=16, fontweight="bold", y=0.98)
    fig.tight_layout(rect=[0, 0, 1, 0.96])
    is_pdf = save_path.lower().endswith('.pdf')

    # ---- Stage data (for page 2 & 3) ----
    th_s = np.linspace(0, np.pi, 360)
    n_uv_s = max(qr['n_uv'] // 2, 14)
    def s_rt(t, p, L, use_r, use_d, use_s):
        return pattern_ray_trace(t, p, L, d_ref, a, b, f,
            feed_dx, feed_dz, shield_D, shield_H=shield_H,
            offset_ang=oa, n_uv=n_uv_s,
            use_reflector=use_r, use_dish=use_d, use_shield=use_s)
    stage_cfgs = [
        ("① 裸偶极子", False, False, False),
        ("② +反射板",  True,  False, False),
        ("③ +抛物面", True,  True,  False),
        ("④ +屏蔽桶", True,  True,  True),
    ]
    st_data = []
    s_bs_t = np.radians(60)
    for sn, ur, ud, us in stage_cfgs:
        Ee_s = np.abs(s_rt(th_s, np.pi/2, length, ur, ud, us))
        Eh_s = np.abs(s_rt(th_s, np.pi, length, ur, ud, us))
        Pe_s = Ee_s / np.max(Ee_s) if np.max(Ee_s) > 0 else Ee_s
        Ph_s = Eh_s / np.max(Eh_s) if np.max(Eh_s) > 0 else Eh_s
        he_s = _hpbw_1d(th_s, Pe_s**2)
        hh_s = _hpbw_1d(th_s, Ph_s**2)
        Pf_s = np.abs(s_rt(s_bs_t, np.pi, length, ur, ud, us))**2
        Pb_s = np.abs(s_rt(np.pi - s_bs_t, 0.0, length, ur, ud, us))**2
        fb_s = 10 * np.log10(Pf_s / Pb_s) if Pb_s > 0 else 40.0
        Pavg_s = (Ee_s**2 + Eh_s**2) / 2
        integ_s = Pavg_s * np.sin(th_s)
        Prad_s = np.trapezoid(integ_s, th_s) * 2 * np.pi
        Umax_s = np.max(Pavg_s)
        Dest_s = 4 * np.pi * Umax_s / Prad_s if Prad_s > 0 else 1
        st_data.append(dict(name=sn, E_e=Ee_s, E_h=Eh_s,
            D_dBi=10*np.log10(Dest_s), HPBW_E=he_s, HPBW_H=hh_s, FB_dB=fb_s))

    # ---- Page 2: Stage Analysis ----
    fig2 = Figure(figsize=(16, 20), dpi=120)
    gs2 = GridSpec(3, 2, figure=fig2, height_ratios=[2, 2, 1.5])
    for i, sd in enumerate(st_data):
        ax = fig2.add_subplot(gs2[i//2, i%2], projection='polar')
        ax.plot(th_s, _polar_radius(sd['E_e'], floor=-30), '#00bc8c', lw=1.5, label='E面')
        ax.plot(th_s, _polar_radius(sd['E_h'], floor=-30), '#e67e22', lw=1.5, label='H面')
        ax.set_ylim(0, 1.05); ax.grid(True, alpha=0.3)
        ax.set_title(f"阶段 {sd['name']}", fontsize=11, fontweight="bold", pad=10)
        if i == 0:
            ax.legend(fontsize=8, loc='upper right')
    ax_t2 = fig2.add_subplot(gs2[2, :])
    ax_t2.axis('off')
    tbl_d2 = [[sd['name'], f"{sd['D_dBi']:.1f}", f"{sd['HPBW_E']:.1f}°",
               f"{sd['HPBW_H']:.1f}°", f"{sd['FB_dB']:.1f}"] for sd in st_data]
    tbl2 = ax_t2.table(cellText=tbl_d2,
        colLabels=['阶段', 'D(dBi)', 'HPBW_E', 'HPBW_H', 'F/B(dB)'],
        loc='center', cellLoc='center', colWidths=[0.2, 0.15, 0.15, 0.15, 0.15])
    tbl2.auto_set_font_size(False); tbl2.set_fontsize(11); tbl2.scale(1, 2.2)
    for j in range(5):
        tbl2[0, j].set_facecolor('#094771')
        tbl2[0, j].set_text_props(color='white', fontweight='bold')
    ax_t2.set_title("阶段指标演进", fontsize=14, fontweight="bold", pad=15)
    fig2.suptitle(f"{C.FREQ/1e6:.1f} MHz 天线仿真 — 渐进结构分析 | {dipole_label}",
                 fontsize=16, fontweight="bold", y=0.98)
    fig2.tight_layout(rect=[0, 0, 1, 0.96])

    # ---- Page 3: Progressive Optimization ----
    fig3 = render_progressive_opt(th_s, st_data, figsize=(16, 12))

    # ---- Page 4: 驻波分析 (SWR) ----
    import standing_wave as sw
    d_ftd = np.linalg.norm([feed_dx, 0, f + feed_dz])
    swr_summary = sw.compute_swr_summary(
        shield_D, shield_H, f, d_ftd,
        freq_start=400e6, freq_end=4000e6, n_pts=600)
    z_rng_sw = (-0.05, shield_H + 0.05)
    r_rng_sw = (0, shield_D / 2)
    Z_sw, R_sw, F_sw = sw.field_distribution_2d(
        z_rng_sw, r_rng_sw, shield_D, shield_H, f, d_ftd, nz=300, nr=120)
    fig4 = _render_swr_export(swr_summary, Z_sw, R_sw, F_sw, params,
                              dipole_label, comp_str)

    # ---- Page 5: 视角场分析 (FOV) ----
    fov_data_export = compute_fov_analysis(
        hpbw_e, hpbw_h, D_dBi, a, b,
        shield_D=shield_D, shield_H=shield_H, dish_f=f,
        use_shield=us)
    fig5 = _render_fov_export(fov_data_export, params, dipole_label, length, qr)

    if is_pdf:
        from matplotlib.backends.backend_pdf import PdfPages
        with PdfPages(save_path) as pdf:
            pdf.savefig(fig, dpi=200, bbox_inches='tight')
            pdf.savefig(fig2, dpi=200, bbox_inches='tight')
            pdf.savefig(fig3, dpi=200, bbox_inches='tight')
            pdf.savefig(fig4, dpi=200, bbox_inches='tight')
            pdf.savefig(fig5, dpi=200, bbox_inches='tight')
        plt.close(fig); plt.close(fig2); plt.close(fig3); plt.close(fig4); plt.close(fig5)
    else:
        # Composite PNG: stack all 5 pages vertically
        import io
        arrs = []
        for fm in [fig, fig2, fig3, fig4, fig5]:
            buf = io.BytesIO()
            fm.savefig(buf, format='png', dpi=150, bbox_inches='tight', pad_inches=0.3)
            buf.seek(0)
            arrs.append(plt.imread(buf))
        min_w = min(a.shape[1] for a in arrs)
        arrs = [a[:, :min_w] for a in arrs]
        plt.imsave(save_path, np.vstack(arrs), dpi=150)
        plt.close(fig); plt.close(fig2); plt.close(fig3); plt.close(fig4); plt.close(fig5)


# ======================== 逐级优化 ========================

def render_progressive_opt(t_1d, stage_data, figsize=(10, 8.5)):
    """逐级优化视图: 4 级极坐标图(每阶段自包含,无跨级叠加)+指标演进表"""
    fig = Figure(figsize=figsize, dpi=100)
    gs = GridSpec(3, 2, figure=fig, height_ratios=[2, 2, 1.2])

    if not stage_data:
        ax_fb = fig.add_subplot(gs[:, :])
        ax_fb.axis('off')
        ax_fb.text(0.5, 0.5, "计算阶段数据中...\n请重新运行仿真",
                  ha='center', va='center', fontsize=12, color='#888888')
        fig.suptitle("逐级优化 — 渐进结构分解", fontsize=12, fontweight="bold", y=0.98)
        fig.tight_layout(rect=[0, 0, 1, 0.96])
        return fig

    c_plane = ['#00bc8c', '#e67e22']
    for idx, sd in enumerate(stage_data):
        row, col = idx // 2, idx % 2
        ax = fig.add_subplot(gs[row, col], projection='polar')
        ax.plot(t_1d, _polar_radius(sd['E_e'], floor=-30), c_plane[0], lw=1.5, label='E面')
        ax.plot(t_1d, _polar_radius(sd['E_h'], floor=-30), c_plane[1], lw=1.5, label='H面')
        ax.set_ylim(0, 1.05); ax.grid(True, alpha=0.3)
        ax.set_title(sd['name'], fontsize=10, fontweight="bold", pad=10)
        for key, clr in [('HPBW_E', '#00bc8c'), ('HPBW_H', '#e67e22')]:
            h = sd.get(key, 0)
            if 10 < h < 170:
                hh = np.radians(h / 2)
                ax.plot([np.pi - hh, np.pi + hh], [0.707, 0.707],
                        color=clr, ls='--', lw=1.2, alpha=0.6)
                ax.annotate(f"{h:.0f}°", xy=(np.pi, 0.75), fontsize=7,
                           color=clr, ha='center', va='bottom',
                           bbox=dict(boxstyle='round,pad=0.1', facecolor='#1e1e1e', alpha=0.5))
        if idx == 0:
            ax.legend(fontsize=7, loc='upper right')

    # 指标演进表
    ax_t = fig.add_subplot(gs[2, :])
    ax_t.axis('off')
    tbl_d = [[sd['name'], f"{sd['D_dBi']:.1f}", f"{sd['HPBW_E']:.1f}°",
              f"{sd['HPBW_H']:.1f}°", f"{sd['FB_dB']:.1f}"] for sd in stage_data]
    tbl = ax_t.table(cellText=tbl_d,
        colLabels=['阶段', 'D (dBi)', 'HPBW_E', 'HPBW_H', 'F/B (dB)'],
        loc='center', cellLoc='center', colWidths=[0.24, 0.14, 0.14, 0.14, 0.16])
    tbl.auto_set_font_size(False); tbl.set_fontsize(9); tbl.scale(1, 2.0)
    for j in range(5):
        tbl[0, j].set_facecolor('#094771')
        tbl[0, j].set_text_props(color='white', fontweight='bold')
    for i in range(1, 5):
        tbl[i, 0].set_facecolor('#2d2d2d')

    fig.suptitle("逐级优化 — 各阶段独立方向图 (无跨级叠加,渲染更轻量)",
                fontsize=12, fontweight="bold", y=0.98)
    fig.tight_layout(rect=[0, 0, 1, 0.96])
    return fig


# ======================== 驻波分析 → 导出专用 ========================

def _render_swr_export(swr_summary, Z_sw, R_sw, F_sw, params,
                       dipole_label, comp_str):
    """导出专用的驻波分析页 (高 DPI 渲染)"""
    fig = Figure(figsize=(18, 14), dpi=150)
    gs = GridSpec(3, 3, figure=fig, height_ratios=[2, 2, 1.2],
                  hspace=0.4, wspace=0.4)

    shield_D = params.get('can_D', 0.5)
    shield_H = params.get('can_H', 0.3)

    # (0,0) SWR vs 频率
    ax_swr = fig.add_subplot(gs[0, 0])
    if swr_summary and swr_summary.get('freq_sweep') is not None:
        fs = swr_summary['freq_sweep'] / 1e6
        sw_ = swr_summary['swr_sweep']
        ax_swr.plot(fs, sw_, '#e74c3c', lw=2)
        ax_swr.axhline(y=1.5, color='gray', ls='--', lw=1, alpha=0.5)
        ax_swr.axhline(y=2.0, color='orange', ls='--', lw=1, alpha=0.5)
        ax_swr.axvline(x=C.FREQ / 1e6, color='#00bc8c', ls='-', lw=1.8, alpha=0.6)
        ax_swr.annotate(f"{C.FREQ/1e6:.0f} MHz\nSWR={swr_summary['swr']:.2f}",
                       xy=(C.FREQ/1e6, swr_summary['swr']),
                       fontsize=10, color='#00bc8c', ha='left',
                       bbox=dict(boxstyle='round,pad=0.3', facecolor='#1e1e1e', alpha=0.8))
        for f_mode, mode_name in swr_summary.get('cavity_modes', []):
            fm = f_mode / 1e6
            if fs[0] <= fm <= fs[-1]:
                ax_swr.axvline(x=fm, color='#3498db', ls=':', lw=0.8, alpha=0.4)
        ax_swr.set_ylim(bottom=0.8, top=min(max(sw_[np.isfinite(sw_)]) * 1.2, 25))
    ax_swr.set_xlabel('频率 (MHz)', fontsize=11)
    ax_swr.set_ylabel('VSWR', fontsize=11)
    ax_swr.set_title('驻波比 SWR vs 频率', fontsize=13, fontweight='bold')
    ax_swr.grid(True, alpha=0.25)

    # (0,1) 回波损耗 & 失配损耗
    ax_rl = fig.add_subplot(gs[0, 1])
    ax_ml = ax_rl.twinx()
    if swr_summary and swr_summary.get('freq_sweep') is not None:
        fs = swr_summary['freq_sweep'] / 1e6
        ax_rl.plot(fs, swr_summary['rl_sweep'], '#00bc8c', lw=2, label='Return Loss')
        ax_ml.plot(fs, swr_summary['ml_sweep'], '#e67e22', lw=1.5, ls='--', label='Mismatch Loss')
        ax_rl.axvline(x=C.FREQ / 1e6, color='#00bc8c', ls='-', lw=1.5, alpha=0.5)
    ax_rl.set_xlabel('频率 (MHz)', fontsize=11)
    ax_rl.set_ylabel('回波损耗 (dB)', fontsize=11, color='#00bc8c')
    ax_ml.set_ylabel('失配损耗 (dB)', fontsize=11, color='#e67e22')
    ax_rl.set_title('回波损耗 & 失配损耗 vs 频率', fontsize=13, fontweight='bold')
    ax_rl.grid(True, alpha=0.25)
    lines1, labels1 = ax_rl.get_legend_handles_labels()
    lines2, labels2 = ax_ml.get_legend_handles_labels()
    ax_rl.legend(lines1 + lines2, labels1 + labels2, fontsize=10, loc='upper right')
    ax_rl.invert_yaxis()

    # (0,2) 驻波指标汇总
    ax_info = fig.add_subplot(gs[0, 2])
    ax_info.axis('off')
    if swr_summary:
        swr_val = swr_summary.get('swr', 0)
        if swr_val < 1.5:
            swr_color, swr_grade = '#00bc8c', '良好'
        elif swr_val < 2.0:
            swr_color, swr_grade = '#f39c12', '一般'
        elif swr_val < 5.0:
            swr_color, swr_grade = '#e74c3c', '较差'
        else:
            swr_color, swr_grade = '#ff0000', '严重'

        lines = [
            f"工作频率: {C.FREQ/1e6:.1f} MHz | λ={C.LAM*100:.1f} cm",
            f"桶 D={shield_D*100:.1f} cm  H={shield_H*100:.1f} cm",
            f"D/λ={shield_D/C.LAM:.2f}  H/λ={shield_H/C.LAM:.2f}",
            "",
            f"◆ 驻波比 SWR: {swr_val:.2f}  [{swr_grade}]",
            f"◆ 回波损耗 RL: {swr_summary['return_loss']:.1f} dB",
            f"◆ 失配损耗 ML: {swr_summary['mismatch_loss']:.3f} dB",
            f"◆ |Γ|: {swr_summary['gamma_mag']:.3f}  ∠Γ: {swr_summary['gamma_phase']:.1f}°",
            "",
            f"频带内 (400-4000 MHz):",
            f"  SWR_max = {swr_summary.get('swr_max_in_band',0):.1f}",
            f"  RL_min  = {swr_summary.get('rl_min_in_band',0):.1f} dB",
            f"  ML_max  = {swr_summary.get('ml_max_in_band',0):.3f} dB",
        ]
        for i, line in enumerate(lines):
            y_pos = 0.96 - i * 0.055
            c = swr_color if line.startswith('◆') and 'SWR' in line else '#cccccc'
            ax_info.text(0.05, y_pos, line, transform=ax_info.transAxes,
                       fontsize=10, color=c, va='top', )
    ax_info.set_title('驻波指标汇总', fontsize=13, fontweight='bold')

    # (1,0:1,1) 桶内驻波场分布 (跨2列)
    ax_field = fig.add_subplot(gs[1, :2])
    if Z_sw is not None and F_sw is not None and np.max(np.abs(F_sw)) > 0:
        zm = Z_sw * 100
        rm = R_sw * 100
        im = ax_field.pcolormesh(zm, rm, np.asarray(F_sw), cmap=plt.cm.hot,
                                 shading='gouraud', vmin=0, vmax=1)
        ax_field.axhline(y=0, color='white', lw=2, alpha=0.6)
        ax_field.axvline(x=0, color='white', lw=2, alpha=0.6)
        if swr_summary:
            d_ftd = np.linalg.norm([params.get('feed_dx', 0), 0,
                                    params.get('dish_f', 0.32) + params.get('feed_dz', 0)])
            ax_field.annotate('馈源', xy=(0, 0), fontsize=11, color='white',
                            ha='center', va='bottom', fontweight='bold',
                            bbox=dict(boxstyle='round', facecolor='red', alpha=0.8))
            ax_field.annotate('抛物面', xy=(d_ftd * 100, 0), fontsize=11, color='white',
                            ha='center', va='top', fontweight='bold',
                            bbox=dict(boxstyle='round', facecolor='#3498db', alpha=0.8))
        cbar = fig.colorbar(im, ax=ax_field, shrink=0.75, pad=0.02)
        cbar.set_label('归一化 |E|', fontsize=11)
    ax_field.set_xlabel('轴向距离 z (cm)', fontsize=11)
    ax_field.set_ylabel('径向距离 r (cm)', fontsize=11)
    ax_field.set_title('桶内驻波场分布 (z-r 平面, TE₁₁模式径向)', fontsize=13, fontweight='bold')

    # (1,2) 增益抖动 (频带内)
    ax_rip = fig.add_subplot(gs[1, 2])
    if swr_summary and swr_summary.get('freq_sweep') is not None:
        f0 = C.FREQ
        fs = swr_summary['freq_sweep']
        ml = swr_summary['ml_sweep']
        bw = 200e6
        bw_mask = (fs >= f0 - bw) & (fs <= f0 + bw)
        if np.any(bw_mask):
            fs_bw = fs[bw_mask] / 1e6
            ml_bw = ml[bw_mask]
            ax_rip.fill_between(fs_bw, ml_bw, alpha=0.3, color='#e67e22')
            ax_rip.plot(fs_bw, ml_bw, '#e67e22', lw=2)
            ax_rip.axvline(x=f0 / 1e6, color='#00bc8c', ls='-', lw=1.5, alpha=0.6)
            ripple = np.max(ml_bw) - np.min(ml_bw)
            ax_rip.annotate(f"抖动={ripple:.3f} dB",
                          xy=(f0 / 1e6, np.mean(ml_bw)),
                          fontsize=10, color='white', ha='center',
                          bbox=dict(boxstyle='round', facecolor='#e74c3c', alpha=0.7))
    ax_rip.set_xlabel('频率 (MHz)', fontsize=11)
    ax_rip.set_ylabel('失配损耗 (dB)', fontsize=11)
    ax_rip.set_title(f'增益抖动 (工作频率 ±{bw/1e6:.0f}MHz)', fontsize=13, fontweight='bold')
    ax_rip.grid(True, alpha=0.25)

    # (2,:) 腔体模式表 + 影响分析
    ax_modes = fig.add_subplot(gs[2, :])
    ax_modes.axis('off')
    modes = swr_summary.get('cavity_modes', []) if swr_summary else []
    f0 = C.FREQ / 1e6

    mode_text = "圆柱腔谐振模式 (TE/TM, 400-4000 MHz):\n\n"
    mode_text += f"{'模式':<12} {'频率(MHz)':<14} {'Δf(MHz)':<14} {'状态'}\n"
    mode_text += "─" * 60 + "\n"

    shown = 0
    for fm, mn in sorted(modes, key=lambda x: abs(x[0]/1e6 - f0))[:15]:
        f_mhz = fm / 1e6
        delta = f_mhz - f0
        if abs(delta) < f0 * 0.015:
            flag = '⚠ 近谐振!'
        elif abs(delta) < f0 * 0.06:
            flag = '● 可能影响'
        else:
            flag = '○ 远离'
        mode_text += f"{mn:<12} {f_mhz:<14.1f} {delta:<+14.1f} {flag}\n"
        shown += 1

    impact_text = (
        f"\n驻波对天线性能的影响分析:\n"
        f"{'─' * 60}\n"
        f"1. 阻抗失配 → 馈源辐射效率降低\n"
        f"   当前失配损耗: {swr_summary.get('mismatch_loss',0):.3f} dB (可忽略)\n"
        f"   频带内最差: {swr_summary.get('ml_max_in_band',0):.3f} dB\n\n"
        f"2. 增益频率响应不平坦 → 宽带工作时性能波动\n"
        f"3. 谐振点方向图畸变 → 旁瓣电平升高\n"
        f"4. 桶尺寸/波长整数倍关系决定谐振频率\n\n"
        f"改善建议:\n"
        f"  • 调整桶直径 D (当前 {shield_D*100:.1f} cm, D/λ={shield_D/C.LAM:.2f})\n"
        f"  • 调整桶高度 H (当前 {shield_H*100:.1f} cm, H/λ={shield_H/C.LAM:.2f})\n"
        f"  • 选择工作频率远离腔体谐振点\n"
        f"  • 桶内壁加吸波材料降低 Q 值, 展宽谐振峰\n"
        f"  • 桶壁开槽/孔破坏谐振条件"
    )
    ax_modes.text(0.03, 0.95, mode_text, transform=ax_modes.transAxes,
                 fontsize=9.5, color='#cccccc', va='top', )
    ax_modes.text(0.52, 0.95, impact_text, transform=ax_modes.transAxes,
                 fontsize=9.5, color='#aaaaaa', va='top', )
    ax_modes.set_title('腔体模式 & 驻波影响评估', fontsize=13, fontweight='bold')

    fig.suptitle(f"{C.FREQ/1e6:.1f} MHz 天线驻波分析 — D={shield_D*100:.1f}cm "
                f"H={shield_H*100:.1f}cm | {dipole_label} | {comp_str}",
                fontsize=16, fontweight="bold", y=0.99)
    return fig


# ======================== 驻波分析 → GUI 标签页 ========================

def render_swr_analysis(swr_summary, Z_sw, R_sw, F_sw, params, length):
    """屏蔽桶驻波分析: SWR 扫频 / 回波损耗 / 场分布 / 腔体模式"""
    import constants as C_sw
    fig = Figure(figsize=(14, 10), dpi=100)
    gs = GridSpec(2, 3, figure=fig, height_ratios=[2.5, 2],
                  hspace=0.35, wspace=0.35)

    shield_D = params.get('can_D', 0.5)
    shield_H = params.get('can_H', 0.3)
    use_shield = params.get('use_shield', True)

    # ===== (0,0) SWR vs 频率 =====
    ax_swr = fig.add_subplot(gs[0, 0])
    if swr_summary and swr_summary.get('freq_sweep') is not None:
        fs = swr_summary['freq_sweep'] / 1e6
        sw_ = swr_summary['swr_sweep']
        ax_swr.plot(fs, sw_, '#e74c3c', lw=1.5)
        ax_swr.axhline(y=1.5, color='gray', ls='--', lw=0.7, alpha=0.6)
        ax_swr.axhline(y=2.0, color='orange', ls='--', lw=0.7, alpha=0.6)
        ax_swr.axvline(x=C_sw.FREQ / 1e6, color='#00bc8c', ls='-', lw=1.2, alpha=0.7)
        ax_swr.annotate(f"{C_sw.FREQ/1e6:.0f} MHz",
                       xy=(C_sw.FREQ/1e6, ax_swr.get_ylim()[1] * 0.95 if ax_swr.get_ylim()[1] > 0 else 5),
                       fontsize=7, color='#00bc8c', ha='center',
                       bbox=dict(boxstyle='round,pad=0.2', facecolor='#1e1e1e', alpha=0.7))

        # 标注腔体模式
        for f_mode, mode_name in swr_summary.get('cavity_modes', []):
            fm = f_mode / 1e6
            if fs[0] <= fm <= fs[-1]:
                ax_swr.axvline(x=fm, color='#3498db', ls=':', lw=0.7, alpha=0.5)
                ax_swr.annotate(mode_name, xy=(fm, ax_swr.get_ylim()[1] * 0.85),
                               fontsize=6, color='#3498db', rotation=90, ha='right',
                               va='top', alpha=0.8)

        ax_swr.set_ylim(bottom=0.8, top=min(max(sw_[np.isfinite(sw_)]) * 1.15, 20))
    ax_swr.set_xlabel('频率 (MHz)', fontsize=9)
    ax_swr.set_ylabel('VSWR', fontsize=9)
    ax_swr.set_title('驻波比 SWR vs 频率', fontsize=10, fontweight='bold')
    ax_swr.grid(True, alpha=0.3)
    ax_swr.text(0.02, 0.96, 'SWR<1.5 良好 | 1.5~2.0 一般 | >2.0 较差',
               transform=ax_swr.transAxes, fontsize=7, color='#888888', va='top')

    # ===== (0,1) 回波损耗 & 失配损耗 vs 频率 =====
    ax_rl = fig.add_subplot(gs[0, 1])
    ax_ml = ax_rl.twinx()
    if swr_summary and swr_summary.get('freq_sweep') is not None:
        fs = swr_summary['freq_sweep'] / 1e6
        ax_rl.plot(fs, swr_summary['rl_sweep'], '#00bc8c', lw=1.5, label='回波损耗')
        ax_ml.plot(fs, swr_summary['ml_sweep'], '#e67e22', lw=1.2, ls='--', label='失配损耗')
        ax_rl.axhline(y=10, color='gray', ls='--', lw=0.7, alpha=0.4)
        ax_rl.axhline(y=14, color='orange', ls='--', lw=0.7, alpha=0.4)
        ax_rl.axvline(x=C_sw.FREQ / 1e6, color='#00bc8c', ls='-', lw=1, alpha=0.5)
    ax_rl.set_xlabel('频率 (MHz)', fontsize=9)
    ax_rl.set_ylabel('回波损耗 (dB)', fontsize=9, color='#00bc8c')
    ax_ml.set_ylabel('失配损耗 (dB)', fontsize=9, color='#e67e22')
    ax_rl.set_title('回波损耗 & 失配损耗 vs 频率', fontsize=10, fontweight='bold')
    ax_rl.grid(True, alpha=0.3)
    lines1, labels1 = ax_rl.get_legend_handles_labels()
    lines2, labels2 = ax_ml.get_legend_handles_labels()
    ax_rl.legend(lines1 + lines2, labels1 + labels2, fontsize=7, loc='upper right')
    ax_rl.invert_yaxis()

    # ===== (0,2) 当前频率指标面板 =====
    ax_info = fig.add_subplot(gs[0, 2])
    ax_info.axis('off')
    if swr_summary:
        swr_val = swr_summary.get('swr', 0)
        rl_val = swr_summary.get('return_loss', 0)
        ml_val = swr_summary.get('mismatch_loss', 0)
        gm_val = swr_summary.get('gamma_mag', 0)
        gp_val = swr_summary.get('gamma_phase', 0)

        # SWR 颜色
        if swr_val < 1.5:
            swr_color = '#00bc8c'
            swr_grade = '良好'
        elif swr_val < 2.0:
            swr_color = '#f39c12'
            swr_grade = '一般'
        elif swr_val < 5.0:
            swr_color = '#e74c3c'
            swr_grade = '较差'
        else:
            swr_color = '#ff0000'
            swr_grade = '严重'

        txt_lines = [
            f"当前频率: {C_sw.FREQ/1e6:.1f} MHz",
            f"λ = {C_sw.LAM*100:.1f} cm",
            f"桶 D={shield_D*100:.1f} cm  H={shield_H*100:.1f} cm",
            f"",
            f"◆ 驻波比 SWR: {swr_val:.2f}",
            f"  评级: {swr_grade}",
            f"",
            f"◆ 回波损耗: {rl_val:.1f} dB",
            f"◆ 失配损耗: {ml_val:.3f} dB",
            f"◆ |Γ|: {gm_val:.3f}",
            f"◆ ∠Γ: {gp_val:.1f}°",
            f"",
            f"频带内最差:",
            f"SWR_max={swr_summary.get('swr_max_in_band',0):.1f}",
            f"RL_min={swr_summary.get('rl_min_in_band',0):.1f}dB",
        ]
        for i, line in enumerate(txt_lines):
            y_pos = 0.96 - i * 0.055
            if line.startswith('◆'):
                color = swr_color if 'SWR' in line else '#d4d4d4'
                ax_info.text(0.05, y_pos, line, transform=ax_info.transAxes,
                           fontsize=8, color=color, va='top', fontweight='bold',
                           )
            else:
                ax_info.text(0.05, y_pos, line, transform=ax_info.transAxes,
                           fontsize=8, color='#aaaaaa', va='top', )

        # SWR 状态指示条
        bar_ax = ax_info.inset_axes([0.1, 0.04, 0.8, 0.04])
        bar_ax.set_xlim(0, 5)
        bar_ax.set_ylim(0, 1)
        bar_ax.axis('off')
        segments = [(0, 1.5, '#00bc8c'), (1.5, 2.0, '#f39c12'),
                    (2.0, 3.0, '#e74c3c'), (3.0, 5.0, '#ff0000')]
        for x0, x1, c in segments:
            bar_ax.axvspan(x0, x1, alpha=0.5, color=c)
        marker_x = min(swr_val, 4.95)
        bar_ax.plot(marker_x, 0.5, 'w^', markersize=8)
        bar_ax.plot(marker_x, 0.5, 'ko', markersize=12, mfc='none')
    ax_info.set_title('驻波指标汇总', fontsize=10, fontweight='bold')

    # ===== (1,0) 桶内驻波场分布 (2D 热力图) =====
    ax_field = fig.add_subplot(gs[1, 0])
    if Z_sw is not None and F_sw is not None and np.max(np.abs(F_sw)) > 0:
        from matplotlib.colors import LinearSegmentedColormap
        cmap_data = [(0, '#1a1a2e'), (0.25, '#16213e'), (0.5, '#0f3460'),
                     (0.7, '#e94560'), (0.85, '#f5a623'), (1.0, '#ffe066')]
        cmap_sw = LinearSegmentedColormap.from_list('sw_field', cmap_data)

        zm = Z_sw * 100  # 转换为 cm
        rm = R_sw * 100
        im = ax_field.pcolormesh(zm, rm, np.asarray(F_sw), cmap=cmap_sw, shading='gouraud',
                                 vmin=0, vmax=1)
        ax_field.axhline(y=0, color='white', lw=1.5, alpha=0.7)
        ax_field.axvline(x=0, color='white', lw=1.5, alpha=0.7)

        # 标注馈源和抛物面位置
        if swr_summary:
            d_ftd = np.linalg.norm([params.get('feed_dx', 0), 0,
                                    params.get('dish_f', 0.32) + params.get('feed_dz', 0)])
            ax_field.annotate('馈源', xy=(0, 0), fontsize=8, color='white',
                            ha='center', va='bottom',
                            bbox=dict(boxstyle='round', facecolor='red', alpha=0.7))
            ax_field.annotate('抛物面', xy=(d_ftd * 100, 0), fontsize=8, color='white',
                            ha='center', va='top',
                            bbox=dict(boxstyle='round', facecolor='#3498db', alpha=0.7))

        cbar = fig.colorbar(im, ax=ax_field, shrink=0.8, pad=0.02)
        cbar.set_label('归一化 |E|', fontsize=8)
    else:
        ax_field.text(0.5, 0.5, '无屏蔽桶或桶尺寸为零\n无法计算场分布',
                     ha='center', va='center', fontsize=10, color='#888888',
                     transform=ax_field.transAxes)
    ax_field.set_xlabel('轴向距离 z (cm)', fontsize=9)
    ax_field.set_ylabel('径向距离 r (cm)', fontsize=9)
    ax_field.set_title('桶内驻波场分布 (z-r 平面)', fontsize=10, fontweight='bold')

    # ===== (1,1) 腔体模式频率表 & 增益影响说明 =====
    ax_modes = fig.add_subplot(gs[1, 1])
    ax_modes.axis('off')
    modes = swr_summary.get('cavity_modes', []) if swr_summary else []

    if modes:
        mode_text = "圆柱腔谐振模式 (预测):\n\n"
        mode_text += f"{'模式':<10} {'频率 (MHz)':<14} {'与工作频率关系'}\n"
        mode_text += "─" * 50 + "\n"
        f0 = C_sw.FREQ / 1e6
        for fm, mn in modes[:12]:
            f_mhz = fm / 1e6
            delta = f_mhz - f0
            if abs(delta) < f0 * 0.02:
                flag = '⚠ 近谐振!'
            elif abs(delta) < f0 * 0.08:
                flag = '● 可能影响'
            else:
                flag = '○ 远离'
            mode_text += f"{mn:<10} {f_mhz:<14.1f} {flag}\n"

        # 驻波影响说明
        impact_text = (
            f"\n驻波对信号的影响:\n"
            f"{'─' * 50}\n"
            f"1. 阻抗失配 → 馈源效率下降\n"
            f"   失配损耗: {swr_summary.get('mismatch_loss',0):.2f} dB\n"
            f"2. 增益抖动 → 频带内增益不平坦\n"
            f"3. 方向图畸变 → 旁瓣增大\n"
            f"4. 谐振点: 桶尺寸/波长整数倍关系\n"
            f"\n改善建议:\n"
            f"• 调整桶直径 D={shield_D*100:.1f}cm\n"
            f"• 调整桶高度 H={shield_H*100:.1f}cm\n"
            f"• 调整工作频率远离谐振点\n"
            f"• 桶内壁加吸波材料降低Q值"
        )
        ax_modes.text(0.05, 0.96, mode_text, transform=ax_modes.transAxes,
                     fontsize=7.5, color='#d4d4d4', va='top', )
        ax_modes.text(0.05, 0.42, impact_text, transform=ax_modes.transAxes,
                     fontsize=7.5, color='#aaaaaa', va='top', )
    else:
        ax_modes.text(0.05, 0.96, "桶尺寸过小或频率范围无谐振模式",
                     fontsize=9, color='#888888', va='top',
                     transform=ax_modes.transAxes)

    ax_modes.set_title('腔体模式 & 影响分析', fontsize=10, fontweight='bold')

    # ===== (1,2) SWR 峰值列表 & 增益抖动 =====
    ax_peaks = fig.add_subplot(gs[1, 2])
    ax_peaks.axis('off')
    peaks = swr_summary.get('swr_peaks', []) if swr_summary else []

    if use_shield and shield_D > 0 and shield_H > 0:
        # 增益抖动估计
        f_sweep = swr_summary.get('freq_sweep', None)
        ml_sweep = swr_summary.get('ml_sweep', None)
        if f_sweep is not None and ml_sweep is not None:
            # 在工作频率附近 ±50MHz 范围内的增益抖动
            f0 = C_sw.FREQ
            bw_mask = (f_sweep >= f0 - 50e6) & (f_sweep <= f0 + 50e6)
            if np.any(bw_mask):
                ripple = np.max(ml_sweep[bw_mask]) - np.min(ml_sweep[bw_mask])
            else:
                ripple = 0

            peak_text = f"SWR 峰值 (谐振频率):\n\n"
            if peaks:
                for fp, sp in sorted(peaks, key=lambda x: x[1], reverse=True)[:8]:
                    peak_text += f"  {fp/1e6:8.1f} MHz  SWR={sp:.1f}\n"
            else:
                peak_text += "  频带内无显著峰值 (SWR<5)\n"

            # 增益相关分析
            gain_text = (
                f"\n增益影响估计:\n"
                f"{'─' * 40}\n"
                f"工作频率 ±50MHz 内:\n"
                f"  失配损耗抖动: {ripple:.3f} dB\n"
                f"  等效增益不平坦度: ±{ripple/2:.3f} dB\n"
                f"\n理论最大增益损失:\n"
                f"  ML_max = {swr_summary.get('ml_max_in_band',0):.3f} dB\n"
                f"  (频带内最差失配点)\n"
                f"\nD/λ = {shield_D/C_sw.LAM:.2f}\n"
                f"H/λ = {shield_H/C_sw.LAM:.2f}"
            )
            ax_peaks.text(0.05, 0.96, peak_text, transform=ax_peaks.transAxes,
                         fontsize=7.5, color='#d4d4d4', va='top', )
            ax_peaks.text(0.05, 0.45, gain_text, transform=ax_peaks.transAxes,
                         fontsize=7.5, color='#aaaaaa', va='top', )
    else:
        ax_peaks.text(0.05, 0.96, "屏蔽桶未启用 (use_shield=False)\n无法计算桶内驻波",
                     fontsize=9, color='#888888', va='top',
                     transform=ax_peaks.transAxes)
    ax_peaks.set_title('谐振峰值 & 增益影响', fontsize=10, fontweight='bold')

    fig.suptitle(f"屏蔽桶驻波分析 — D={shield_D*100:.1f}cm H={shield_H*100:.1f}cm "
                f"| {C_sw.FREQ/1e6:.1f} MHz",
                fontsize=12, fontweight="bold", y=0.99)
    return fig


# ======================== 视角场分析 ========================

def _generate_fov_cone_mesh(feed_pos, u_hat, e1, e2, hp_e_half_rad, hp_h_half_rad,
                             length=1.5, n_rho=20, n_phi=48):
    """生成椭圆锥面网格 (视角场 3dB 波束轮廓)"""
    rho = np.linspace(0.02, length, n_rho)
    phi = np.linspace(0, 2 * np.pi, n_phi)
    Rho, Phi = np.meshgrid(rho, phi, indexing='ij')

    a = np.tan(hp_h_half_rad)
    b = np.tan(hp_e_half_rad)
    cos_p = np.cos(Phi)
    sin_p = np.sin(Phi)
    r_ellipse = a * b / np.sqrt(np.clip((b * cos_p)**2 + (a * sin_p)**2, 1e-12, None))
    R = Rho * r_ellipse

    base_x = feed_pos[0] + Rho * u_hat[0]
    base_y = feed_pos[1] + Rho * u_hat[1]
    base_z = feed_pos[2] + Rho * u_hat[2]

    X = base_x + R * (e1[0] * cos_p + e2[0] * sin_p)
    Y = base_y + R * (e1[1] * cos_p + e2[1] * sin_p)
    Z = base_z + R * (e1[2] * cos_p + e2[2] * sin_p)

    return X, Y, Z


def _generate_shield_rim_ring(feed_pos, u_hat, e1, e2, rim_dist, rim_radius, n=80):
    """生成屏蔽桶边缘环 (3D 圆圈)"""
    phi = np.linspace(0, 2 * np.pi, n)
    cx = feed_pos[0] + rim_dist * u_hat[0]
    cy = feed_pos[1] + rim_dist * u_hat[1]
    cz = feed_pos[2] + rim_dist * u_hat[2]
    x = cx + rim_radius * (e1[0] * np.cos(phi) + e2[0] * np.sin(phi))
    y = cy + rim_radius * (e1[1] * np.cos(phi) + e2[1] * np.sin(phi))
    z = cz + rim_radius * (e1[2] * np.cos(phi) + e2[2] * np.sin(phi))
    return x, y, z


def _generate_circ_cone_mesh(feed_pos, u_hat, half_angle_rad, length=1.5,
                              n_rho=18, n_phi=60):
    """生成圆形锥面网格 (用于屏蔽桶几何限制锥)"""
    rho = np.linspace(0.02, length, n_rho)
    phi = np.linspace(0, 2 * np.pi, n_phi)
    Rho, Phi = np.meshgrid(rho, phi, indexing='ij')

    r_tan = np.tan(half_angle_rad)
    R = Rho * r_tan

    # 需要正交基
    if abs(u_hat[2]) < 0.9:
        v1 = np.array([-u_hat[1], u_hat[0], 0.0])
    else:
        v1 = np.array([1.0, 0.0, 0.0])
    v1 /= np.linalg.norm(v1)
    v2 = np.cross(u_hat, v1)
    v2 /= np.linalg.norm(v2)

    base_x = feed_pos[0] + Rho * u_hat[0]
    base_y = feed_pos[1] + Rho * u_hat[1]
    base_z = feed_pos[2] + Rho * u_hat[2]

    X = base_x + R * (v1[0] * np.cos(Phi) + v2[0] * np.sin(Phi))
    Y = base_y + R * (v1[1] * np.cos(Phi) + v2[1] * np.sin(Phi))
    Z = base_z + R * (v1[2] * np.cos(Phi) + v2[2] * np.sin(Phi))

    return X, Y, Z


def render_fov_analysis(params, dip_type_name, length, metrics, fov_data, qr):
    """视角场分析: 3D 结构 + 圆锥 + 屏蔽桶影响 + 覆盖范围"""
    dish_a = params['dish_a']
    dish_b = params['dish_b']
    dish_f = params['dish_f']
    oa = params['offset_ang']
    feed_dx = params['feed_dx']
    feed_dz = params['feed_dz']
    shield_D = params['can_D']
    shield_H = params['can_H']
    cyl_R = params['cyl_R']
    cyl_L = params['cyl_L']
    cyl_ang = params['cyl_ang']
    rx = params.get('can_rot_x', 0)
    ry = params.get('can_rot_y', 0)
    show_shield = params.get('show_shield', True)
    ud = params.get('use_dish', True)
    ur = params.get('use_reflector', True)
    use_shield = params.get('use_shield', True)

    f = dish_f
    u_hat, e1, e2, F = _offset_axis(f, oa, feed_dx, feed_dz)
    feed = np.array([feed_dx, 0, f + feed_dz])

    shield_limited = fov_data.get('shield_limited', False)
    shield_rim_deg = fov_data.get('shield_rim_deg', 90)
    shield_rim_rad = np.radians(shield_rim_deg)
    rim_dist = dish_f + shield_H

    # 有效 FOV 圆锥半角 (考虑屏蔽桶)
    eff_cone_half_deg = fov_data.get('cone_half_angle',
        np.sqrt(fov_data['hpbw_e_deg'] * fov_data['hpbw_h_deg']) / 2.0)
    eff_cone_half_rad = np.radians(eff_cone_half_deg)

    cone_len = max(dish_a, dish_b, shield_H, abs(feed[2]), abs(feed[0])) * 2.2

    fig = Figure(figsize=(14, 9.5), dpi=100)
    gs = GridSpec(1, 2, figure=fig, width_ratios=[2.5, 1], wspace=0.05)

    # ===== 左: 3D 结构 + FOV 圆锥 + 屏蔽桶边缘 =====
    ax = fig.add_subplot(gs[0, 0], projection='3d')

    render_structure(ax, length, dish_a, dish_b, f, oa, show_shield,
                     shield_D, shield_H, cyl_R, cyl_L, cyl_ang,
                     feed_dx, feed_dz, rx, ry,
                     nr=qr['dish_nr'], np_=qr['dish_np'],
                     cyl_nu=qr['cyl_nu'], cyl_nv=qr['cyl_nv'],
                     show_dish=ud, show_reflector=ur)

    legend_items = []

    # ── 自然波束圆锥 (无屏蔽桶, 半透明灰色) ──
    if shield_limited:
        natural_half = np.radians(np.sqrt(fov_data['hpbw_e_deg'] *
                                          fov_data['hpbw_h_deg']) / 2.0)
        hp_e_nat = np.radians(fov_data['hpbw_e_deg'] / 2.0)
        hp_h_nat = np.radians(fov_data['hpbw_h_deg'] / 2.0)
        Xn, Yn, Zn = _generate_fov_cone_mesh(
            feed, u_hat, e1, e2, hp_e_nat, hp_h_nat, length=cone_len,
            n_rho=12, n_phi=40)
        ax.plot_surface(Xn, Yn, Zn, color='gray', alpha=0.04,
                        rstride=3, cstride=8, edgecolor='gray',
                        linewidth=0.15, linestyle=':')
        l_nat = Line2D([0], [0], color='gray', lw=1, alpha=0.4, ls=':',
                       label='自然波束 (无桶)')
        legend_items.append(l_nat)

    # ── 有效 FOV 圆锥 (青色, 3dB) ──
    hp_e_rad = np.radians(fov_data['hpbw_e_deg'] / 2.0)
    hp_h_rad = np.radians(fov_data['hpbw_h_deg'] / 2.0)
    if shield_limited:
        # 被桶截断: 圆锥到桶口为止, 半角取桶边缘角
        plot_half_e = min(hp_e_rad, shield_rim_rad)
        plot_half_h = min(hp_h_rad, shield_rim_rad)
    else:
        plot_half_e = hp_e_rad
        plot_half_h = hp_h_rad

    if plot_half_e > 0 and plot_half_h > 0:
        Xc, Yc, Zc = _generate_fov_cone_mesh(
            feed, u_hat, e1, e2, plot_half_e, plot_half_h, length=cone_len,
            n_rho=18, n_phi=60)
        ax.plot_surface(Xc, Yc, Zc, color='cyan', alpha=0.10,
                        rstride=3, cstride=6, edgecolor='cyan',
                        linewidth=0.3, linestyle='-')
        ax.plot_wireframe(Xc, Yc, Zc, rstride=6, cstride=12,
                          color='cyan', alpha=0.15, linewidth=0.2)
        l_eff = Line2D([0], [0], color='cyan', lw=1.5, alpha=0.7,
                       label='有效 FOV (3dB)')
        legend_items.append(l_eff)

        # E面 / H面 交线
        for phi_deg, color, label, ls in [
            (0, '#e67e22', 'H面', '-'),
            (90, '#00bc8c', 'E面', '-'),
        ]:
            phi_r = np.radians(phi_deg)
            cos_p = np.cos(phi_r); sin_p = np.sin(phi_r)
            a_r = np.tan(plot_half_h); b_r = np.tan(plot_half_e)
            r_edge = a_r * b_r / np.sqrt(max((b_r * cos_p)**2 + (a_r * sin_p)**2, 1e-12))
            rho_line = np.linspace(0, cone_len, 40)
            r_line = rho_line * r_edge
            x_line = feed[0] + rho_line * u_hat[0] + r_line * (e1[0]*cos_p + e2[0]*sin_p)
            y_line = feed[1] + rho_line * u_hat[1] + r_line * (e1[1]*cos_p + e2[1]*sin_p)
            z_line = feed[2] + rho_line * u_hat[2] + r_line * (e1[2]*cos_p + e2[2]*sin_p)
            ax.plot(x_line, y_line, z_line, color=color, lw=1.8, alpha=0.9, ls=ls, label=label)

    # ── 屏蔽桶边缘环 (红色) ──
    if use_shield and shield_D > 1e-9:
        shield_R = shield_D / 2.0
        xr, yr, zr = _generate_shield_rim_ring(feed, u_hat, e1, e2, rim_dist, shield_R)
        ax.plot(xr, yr, zr, color='red', lw=2.5, alpha=0.9, ls='-')
        ax.scatter(xr[0], yr[0], zr[0], color='red', s=15, zorder=8)
        l_rim = Line2D([0], [0], color='red', lw=2, alpha=0.9,
                       label=f'桶边缘 (θ={shield_rim_deg:.1f}°)')
        legend_items.append(l_rim)

        # 屏蔽桶几何限制锥 (淡红色虚线圆锥)
        if shield_limited and shield_rim_rad > 0.01:
            Xs, Ys, Zs = _generate_circ_cone_mesh(
                feed, u_hat, shield_rim_rad, length=cone_len * 0.7,
                n_rho=10, n_phi=48)
            ax.plot_wireframe(Xs, Ys, Zs, rstride=4, cstride=10,
                              color='red', alpha=0.12, linewidth=0.25, ls=':')
            l_geo = Line2D([0], [0], color='red', lw=0.8, alpha=0.4, ls=':',
                           label='桶几何截止')
            legend_items.append(l_geo)

    # 光轴
    ax.plot([feed[0], feed[0] + cone_len * u_hat[0]],
            [feed[1], feed[1] + cone_len * u_hat[1]],
            [feed[2], feed[2] + cone_len * u_hat[2]],
            'cyan', lw=0.8, alpha=0.35, ls='--')
    l_ax = Line2D([0], [0], color='cyan', lw=0.8, alpha=0.4, ls='--',
                  label='光轴')
    legend_items.append(l_ax)

    ax.legend(handles=legend_items, fontsize=7, loc='upper left')

    if shield_limited:
        ax.set_title("天线结构 + 视角场圆锥 (含屏蔽桶截断效应)",
                     fontsize=11, fontweight="bold")
    else:
        ax.set_title("天线结构 + 视角场圆锥 (3dB HPBW 椭圆锥)",
                     fontsize=11, fontweight="bold")

    # ===== 右: 指标面板 =====
    ax_info = fig.add_subplot(gs[0, 1])
    ax_info.axis('off')

    full_sky_sqdeg = 41253.0
    moon_sqdeg = 0.2

    fov_eff_sq = fov_data['fov_effective_sqdeg']
    omega_sq = fov_data['omega_beam_sqdeg']
    omega_sh_sq = fov_data.get('omega_shield_sqdeg', omega_sq)
    tr_ratio = fov_data.get('truncation_ratio', 1.0)
    n_beams = fov_data['n_beams_sky']
    n_beams_nat = fov_data.get('n_beams_sky_natural', n_beams)

    shield_color = '#e74c3c' if shield_limited else '#00bc8c'
    shield_label = '⚠ 屏蔽桶限制了视场' if shield_limited else '✓ 屏蔽桶未限制视场'

    lines = [
        ("视角场分析 (FOV)", '#00bc8c', True),
        ("══════════════════", '#555555', False),
        (f"频率: {C.FREQ/1e6:.1f} MHz  λ={C.LAM*100:.1f} cm", '#d4d4d4', False),
        (f"有效口径 D_eff: {fov_data['D_eff']*100:.1f} cm", '#d4d4d4', False),
        ("", '#000000', False),
        ("── 波束参数 ──", '#e67e22', True),
        (f"E面 HPBW: {fov_data['hpbw_e_deg']:.2f}°", '#00bc8c', False),
        (f"H面 HPBW: {fov_data['hpbw_h_deg']:.2f}°", '#e67e22', False),
        (f"平均 HPBW: {fov_data['avg_hpbw_deg']:.2f}°", '#d4d4d4', False),
        ("", '#000000', False),
        ("── 屏蔽桶影响 ──", '#e74c3c', True),
        (f"{shield_label}", shield_color, True),
        (f"桶边缘角 θ_rim: {shield_rim_deg:.1f}°", '#d4d4d4', False),
        (f"桶几何限制: {omega_sh_sq:.1f} 平方度", '#d4d4d4', False),
        (f"视场压缩比: {tr_ratio:.2%}", shield_color, False),
        ("", '#000000', False),
        ("── 有效视角场 ──", '#3498db', True),
        (f"有效 FOV: {fov_eff_sq:.1f} 平方度", '#ffffff', True),
        (f"≈ {fov_eff_sq / moon_sqdeg:.0f} 个满月面积", '#f39c12', False),
        (f"占全天: {fov_eff_sq / full_sky_sqdeg * 100:.3f}%", '#888888', False),
        ("", '#000000', False),
        ("── 自然波束 (无桶) ──", '#888888', True),
        (f"Ω_natural: {omega_sq:.1f} 平方度", '#888888', False),
        (f"覆盖全天需 ≈{n_beams_nat:.0f} 波束", '#888888', False),
        ("", '#000000', False),
        ("── 巡天能力 (实际) ──", '#9b59b6', True),
        (f"覆盖全天需 ≈{n_beams:.0f} 波束", '#d4d4d4', False),
        (f"角分辨率: {fov_data['theta_res_deg']:.3f}°", '#d4d4d4', False),
        (f"指向性 D: {fov_data['D_dBi']:.1f} dBi", '#d4d4d4', False),
    ]

    y_pos = 0.975
    for text, color, is_bold in lines:
        fontsize = 9.5 if is_bold else 8
        weight = 'bold' if is_bold else 'normal'
        ax_info.text(0.05, y_pos, text, transform=ax_info.transAxes,
                    fontsize=fontsize, color=color, va='top',
                    fontweight=weight)
        if text == "":
            y_pos -= 0.006
        else:
            y_pos -= 0.025 if not is_bold else 0.028

    # 底部图例
    y_bot = 0.04
    ax_info.text(0.05, y_bot, "青色椭圆锥 = 有效 3dB FOV",
                transform=ax_info.transAxes, fontsize=7, color='cyan', va='bottom')
    ax_info.text(0.05, y_bot - 0.025, "红色环 = 屏蔽桶出口边缘",
                transform=ax_info.transAxes, fontsize=7, color='red', va='bottom')
    if shield_limited:
        ax_info.text(0.05, y_bot - 0.05, "灰色虚线 = 自然波束(被截断)",
                    transform=ax_info.transAxes, fontsize=7, color='gray', va='bottom')

    fig.suptitle(f"视角场分析 — {dip_type_name} | 屏蔽桶{'截断' if shield_limited else '无影响'}",
                fontsize=13, fontweight="bold", y=0.99)
    return fig


def _render_fov_export(fov_data, params, dip_type_name, length, qr):
    """导出专用: 视角场分析完整页 (高 DPI)"""
    dish_a = params['dish_a']
    dish_b = params['dish_b']
    dish_f = params['dish_f']
    oa = params['offset_ang']
    feed_dx = params['feed_dx']
    feed_dz = params['feed_dz']
    shield_D = params['can_D']
    shield_H = params['can_H']
    cyl_R = params['cyl_R']
    cyl_L = params['cyl_L']
    cyl_ang = params['cyl_ang']
    rx = params.get('can_rot_x', 0)
    ry = params.get('can_rot_y', 0)
    show_shield = params.get('show_shield', True)
    ud = params.get('use_dish', True)
    ur = params.get('use_reflector', True)
    use_shield = params.get('use_shield', True)

    f = dish_f
    u_hat, e1, e2, F = _offset_axis(f, oa, feed_dx, feed_dz)
    feed = np.array([feed_dx, 0, f + feed_dz])

    shield_limited = fov_data.get('shield_limited', False)
    shield_rim_deg = fov_data.get('shield_rim_deg', 90)
    shield_rim_rad = np.radians(shield_rim_deg)
    rim_dist = dish_f + shield_H

    cone_len = max(dish_a, dish_b, shield_H, abs(feed[2]), abs(feed[0])) * 2.2
    full_sky_sqdeg = 41253.0
    moon_sqdeg = 0.2

    fig = Figure(figsize=(18, 13), dpi=150)
    gs = GridSpec(2, 3, figure=fig, height_ratios=[2.5, 1.4],
                  hspace=0.3, wspace=0.3)

    # (0,0):0 (0,1):1 — 3D 结构 + 圆锥 (跨两列)
    ax3d = fig.add_subplot(gs[0, :2], projection='3d')
    render_structure(ax3d, length, dish_a, dish_b, f, oa, show_shield,
                     shield_D, shield_H, cyl_R, cyl_L, cyl_ang,
                     feed_dx, feed_dz, rx, ry,
                     nr=qr['dish_nr']*2, np_=qr['dish_np']*2,
                     cyl_nu=qr['cyl_nu'], cyl_nv=qr['cyl_nv'],
                     show_dish=ud, show_reflector=ur)

    # 有效 FOV 圆锥
    hp_e_rad = np.radians(fov_data['hpbw_e_deg'] / 2.0)
    hp_h_rad = np.radians(fov_data['hpbw_h_deg'] / 2.0)
    if shield_limited:
        plot_he = min(hp_e_rad, shield_rim_rad)
        plot_hh = min(hp_h_rad, shield_rim_rad)
    else:
        plot_he = hp_e_rad
        plot_hh = hp_h_rad

    if plot_he > 0 and plot_hh > 0:
        Xc, Yc, Zc = _generate_fov_cone_mesh(
            feed, u_hat, e1, e2, plot_he, plot_hh, length=cone_len,
            n_rho=24, n_phi=72)
        ax3d.plot_surface(Xc, Yc, Zc, color='cyan', alpha=0.10,
                          rstride=3, cstride=6, edgecolor='cyan',
                          linewidth=0.3, linestyle='-')
        ax3d.plot_wireframe(Xc, Yc, Zc, rstride=6, cstride=12,
                            color='cyan', alpha=0.12, linewidth=0.2)

    # 自然波束 (灰色虚线)
    if shield_limited:
        hp_e_n = np.radians(fov_data['hpbw_e_deg'] / 2.0)
        hp_h_n = np.radians(fov_data['hpbw_h_deg'] / 2.0)
        Xn, Yn, Zn = _generate_fov_cone_mesh(
            feed, u_hat, e1, e2, hp_e_n, hp_h_n, length=cone_len,
            n_rho=12, n_phi=40)
        ax3d.plot_wireframe(Xn, Yn, Zn, rstride=5, cstride=10,
                            color='gray', alpha=0.10, linewidth=0.2)

    # 屏蔽桶边缘环
    if use_shield and shield_D > 1e-9:
        shield_R = shield_D / 2.0
        xr, yr, zr = _generate_shield_rim_ring(feed, u_hat, e1, e2, rim_dist, shield_R)
        ax3d.plot(xr, yr, zr, color='red', lw=3, alpha=0.9, ls='-')
        ax3d.scatter(xr[0], yr[0], zr[0], color='red', s=30, zorder=9)

    # 光轴
    ax3d.plot([feed[0], feed[0] + cone_len * u_hat[0]],
              [feed[1], feed[1] + cone_len * u_hat[1]],
              [feed[2], feed[2] + cone_len * u_hat[2]],
              'cyan', lw=1, alpha=0.4, ls='--')

    ax3d.set_title("天线结构 + 视角场圆锥 (3dB HPBW + 屏蔽桶截断)",
                   fontsize=14, fontweight="bold")

    # (0,2) 指标汇总
    ax_info = fig.add_subplot(gs[0, 2])
    ax_info.axis('off')

    omega_sq = fov_data['omega_beam_sqdeg']
    fov_eff = fov_data['fov_effective_sqdeg']
    omega_sh = fov_data.get('omega_shield_sqdeg', omega_sq)
    tr_ratio = fov_data.get('truncation_ratio', 1.0)

    txt = (
        f"══════════════════════\n"
        f"  视角场 (FOV) 分析报告\n"
        f"══════════════════════\n\n"
        f"工作频率: {C.FREQ/1e6:.1f} MHz\n"
        f"波长 λ = {C.LAM*100:.1f} cm\n"
        f"有效口径 D_eff = {fov_data['D_eff']*100:.1f} cm\n\n"
        f"── 波束参数 ──\n"
        f"E 面 HPBW: {fov_data['hpbw_e_deg']:.2f}°\n"
        f"H 面 HPBW: {fov_data['hpbw_h_deg']:.2f}°\n"
        f"平均 HPBW: {fov_data['avg_hpbw_deg']:.2f}°\n"
        f"角分辨率 (Rayleigh): {fov_data['theta_res_deg']:.4f}°\n\n"
        f"── 屏蔽桶影响 ──\n"
        f"桶 D={shield_D*100:.1f}cm H={shield_H*100:.1f}cm\n"
        f"边缘角 θ_rim: {shield_rim_deg:.1f}°\n"
        f"几何限制 FOV: {omega_sh:.1f} sq.deg\n"
        f"视场限制: {'是 ⚠' if shield_limited else '否 ✓'}\n"
        f"压缩比: {tr_ratio:.2%}\n\n"
        f"── 有效视角场 ──\n"
        f"有效 FOV: {fov_eff:.1f} 平方度\n"
        f"≈ {fov_eff / moon_sqdeg:.0f} 个满月面积\n"
        f"占全天空: {fov_eff / full_sky_sqdeg * 100:.4f}%\n\n"
        f"── 巡天能力 ──\n"
        f"覆盖全天需 ≈{fov_data['n_beams_sky']:.0f} 波束\n"
        f"自然波束需 ≈{fov_data.get('n_beams_sky_natural',0):.0f} 波束\n"
        f"指向性 D: {fov_data['D_dBi']:.1f} dBi\n"
    )
    ax_info.text(0.05, 0.98, txt, transform=ax_info.transAxes,
                fontsize=10, color='#d4d4d4', va='top',
                bbox=dict(boxstyle='round', facecolor='#2d2d2d',
                          edgecolor='#555', alpha=0.9, pad=0.8))

    # (1,:) 视场对比说明
    ax_comp = fig.add_subplot(gs[1, :])
    ax_comp.axis('off')

    comp_text = (
        f"══════════════════════════════════════════════════════════════════\n"
        f"  射电望远镜视角场 (Field of View) 解释\n"
        f"══════════════════════════════════════════════════════════════════\n\n"
        f"1. 波束立体角 (Beam Solid Angle) Ω_A:\n"
        f"   Ω_A = 4π / D  (D 为指向性线性值)\n"
        f"   当前 Ω_A = {omega_sq:.1f} 平方度 (自然波束, 不含屏蔽桶)\n\n"
        f"2. 屏蔽桶效应:\n"
        f"   屏蔽桶出口在距离 dish_f+H = {dish_f+shield_H:.3f}m 处\n"
        f"   边缘角 θ_rim = arctan(R_shield / (dish_f + shield_H))\n"
        f"                 = arctan({shield_D/2*100:.1f} / {dish_f+shield_H*100:.1f}) = {shield_rim_deg:.1f}°\n"
        f"   桶几何锥立体角: Ω_shield = 2π(1 - cos(θ_rim)) = {omega_sh:.1f} 平方度\n"
    )
    if shield_limited:
        comp_text += (
            f"   ⚠ 屏蔽桶限制了视场! 自然波束半角 > 桶边缘角\n"
            f"   有效 FOV = 桶几何限制 × 0.85 (边缘衍射修正)\n"
            f"   视场被压缩至原来的 {tr_ratio:.1%}\n\n"
        )
    else:
        comp_text += (
            f"   ✓ 屏蔽桶未限制视场, 桶边缘角 ({shield_rim_deg:.1f}°) 大于波束半角\n\n"
        )
    comp_text += (
        f"3. 有效视角场:\n"
        f"   有效覆盖 = {fov_eff:.1f} 平方度 ≈ {fov_eff/moon_sqdeg:.0f} 个满月\n"
        f"   全天 = 41253 平方度, 需要 ≈{fov_data['n_beams_sky']:.0f} 次指向覆盖全天\n\n"
        f"4. 角分辨率: θ_res = 1.22 × λ / D_eff = {fov_data['theta_res_deg']:.4f}°\n"
        f"   对应 {fov_data['theta_res_deg']*60:.2f} 角分, {fov_data['theta_res_deg']*3600:.1f} 角秒\n\n"
        f"5. 参考:\n"
        f"   • 中性氢巡天 (HIPASS): 15.5' 分辨率, 覆盖南部天球\n"
        f"   • Arecibo ALFA: 3.5' × 3.8' @ 1420MHz\n"
        f"   • FAST 19波束接收机: ~3' @ 1420MHz\n"
        f"   • 本天线属于小型馈源天线, 适合宽视场探测而非高分辨率成像\n"
    )
    ax_comp.text(0.04, 0.98, comp_text, transform=ax_comp.transAxes,
                fontsize=9.5, color='#cccccc', va='top', )

    fig.suptitle(f"视角场分析报告 — {dip_type_name} | "
                f"D_eff={fov_data['D_eff']*100:.1f}cm | "
                f"FOV={fov_data['fov_effective_sqdeg']:.1f} sq.deg",
                fontsize=16, fontweight="bold", y=0.99)
    return fig
